"""Source-locked experimental TSBB04B profiles. Never flashes a device."""
from pathlib import Path
import struct,sys,json,zlib,hashlib,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R));from analyze_ota import KEY,norline
MASKS=[sum(1<<(t-1) for t in norline.LAGS[j] if t<=31) for j in range(8)]
def codec(data,encode=False):
 out=bytearray(len(data))
 for base in range(0,len(data),32):
  h=0
  for k,v in enumerate(data[base:base+32]):
   mask=KEY[k]^sum(((h&m).bit_count()&1)<<j for j,m in enumerate(MASKS));plain=v if encode else v^mask
   out[base+k]=v^mask;h=(h<<1)|((plain&0x3c).bit_count()&1)
 return bytes(out)
def parts(b):
 return {b[o:o+16].split(b'\0')[0].decode(): (o,*struct.unpack_from('<4I',b,o+16)) for o in range(512,512+32*struct.unpack_from('<I',b,12)[0],32)}
def verify(b):
 assert b[:4]==b'AOTA' and len(b)==struct.unpack_from('<I',b,20)[0]
 assert zlib.crc32(b[8:1024])==struct.unpack_from('<I',b,4)[0]
 assert zlib.crc32(b[1024:])==struct.unpack_from('<I',b,24)[0]
 p=parts(b)
 for _,off,size,_,crc in p.values():assert off+size<=len(b) and zlib.crc32(b[off:off+size])==crc
 _,o,n,_,_=p['ota.xml']
 for e in ET.fromstring(b[o:o+n]).findall('./partitions/partition'):
  _,o,n,_,crc=p[e.findtext('file_name')];assert int(e.findtext('file_size'),0)==n and int(e.findtext('checksum'),0)==crc
 return p

def jal(address):
 assert address%4==0
 v=(address>>2)&0x3ffffff
 return struct.pack('<HH',0x1800|(((v>>16)&31)<<5)|((v>>21)&31),v&65535)
assert jal(0xbf0675a4)==bytes.fromhex('3e18699d')

def build(source,arc=False,center=False):
 b=Path(source).read_bytes();assert hashlib.sha256(b).hexdigest()=='6194cc9a9cd03ca20c57fbe9b7adf3edec1f03b79d60aabd8fa4a84003b0fde0'
 p=verify(b);entry,o,n,_,oldcrc=p['zephyr.bin'];plain=codec(b[o:o+n]);assert plain==(R/'decoded/zephyr.bin').read_bytes();assert codec(plain,True)==b[o:o+n]
 patched=bytearray(plain);edits=[]
 def edit(at,expected,new,purpose):
  if isinstance(expected,str):expected=bytes.fromhex(expected)
  if isinstance(new,str):new=bytes.fromhex(new)
  assert len(expected)==len(new) and plain[at:at+len(expected)]==expected,(hex(at),purpose)
  assert patched[at:at+len(expected)]==expected,'overlapping edit'
  patched[at:at+len(new)]=new;edits.append(dict(offset=hex(at),before=expected.hex(),after=new.hex(),purpose=purpose))
 edit(0x49180,'515a','325a','display first stage 50 ticks')
 edit(0x491e6,'c0f51d5b','325b0065','display second stage 50 ticks plus nop')
 # Carry over the previously verified bounded name storage change.
 name=b'Tuvio Studio 5.1.2 Pro';edit(0xa886c,b'TSBB04B\0%s: Succ @@@ \n\n\0',(name+b'\0').ljust(24,b'\0'),'OTA Bluetooth name (conditional application)')
 edit(0x178fc,struct.pack('<I',0xbf0a8874),struct.pack('<I',0xbf0a8883),'redirect overlapping success-log format to empty string')
 if arc or center:
  start=0xc69ac;size=124;old=plain[start:start+size]
  assert old.startswith(b'%s: res_in_samples %d,') and old[-1:]==b'\0'
  blob=(R/'research-v3/arc-hooks.bin').read_bytes();assert len(blob)==84 and blob[4:10]==bytes.fromhex('e3643e18699d')
  storage=bytearray(size);storage[:len(blob)]=blob
  if center:
   table=bytes(0xbf+2*i for i in range(21));assert table[10]==plain[0xb7c14+5]
   assert table[5:16]==plain[0xb7c14:0xb7c14+11]
   storage[0x54:0x54+21]=table # address 0xbf0c6a00
  edit(start,old,bytes(storage),'relocate one diagnostic format storage to ARC helpers and optional center table')
  assert plain.count(struct.pack('<I',0xbf0c69ac))==1
  edit(0x7d134,struct.pack('<I',0xbf0c69ac),struct.pack('<I',0xbf0c6a27),'redirect replaced diagnostic format to terminating empty string')
  if arc:
   edit(0x498f2,jal(0xbf0675a4),jal(0xbf0c69b0),'active ARC application blocks automatic idle-state entry')
   edit(0x205e0,'e5b540ab',jal(0xbf0c69d0),'active ARC application resets input idle counter and keeps flag armed')
   assert patched[0x205e4:0x205e6]==bytes.fromhex('016e'),'keep original li a2,1 delay slot'
 if center:
  for at,old,new,why in [
   (0x4e0ba,'0c5a','165a','center increment bound 22'),(0x4e0be,'0b68','1568','center increment clamp 21'),
   (0x4ee4a,'0b5c','155c','center driver bound 21'),(0x4ee4e,'0a6a','146a','center driver clamp 20'),
   (0x177b8,'056d','0b6d','OTA center neutral stored index 11'),
   (0x4e330,'056c','0a6c','EQ reset center neutral hardware index 10'),(0x4e332,'066d','0b6d','EQ reset center neutral stored index 11'),
   (0x4847a,'055b','0a5b','center display negative boundary'),(0x4847e,'0569','0a69','center display negative magnitude base 10'),
   (0x4848e,'0573','0a73','center display neutral index 10'),
   (0x48498,'2a42016e11e9','2267f549016e','center display positive magnitude stored value minus 11')]:edit(at,old,new,why)
  edit(0x4ee80,struct.pack('<I',0xbf0b7c14),struct.pack('<I',0xbf0c6a00),'center expanded 21-entry register table')
 # CEC message dispatch and standby opcode remain byte-identical.
 assert patched[0x51264:0x512f6]==plain[0x51264:0x512f6]
 # External SW/SURR handlers stay unchanged: receiver protocol range is unknown.
 for a,z in [(0x4e01c,0x4e09c),(0x4e110,0x4e1ae)]:assert patched[a:z]==plain[a:z]
 encoded=codec(patched,True);assert codec(encoded)==patched
 affected={i//32 for i,(a,c) in enumerate(zip(plain,patched)) if a!=c}
 assert all(a==c for i,(a,c) in enumerate(zip(b[o:o+n],encoded)) if i//32 not in affected)
 out=bytearray(b);out[o:o+n]=encoded;crc=zlib.crc32(encoded);struct.pack_into('<I',out,entry+28,crc)
 xe,xo,xn,_,_=p['ota.xml'];xml=bytes(out[xo:xo+xn]);old=f'0x{oldcrc:08x}'.encode();assert xml.count(old)==1;xml=xml.replace(old,f'0x{crc:08x}'.encode());out[xo:xo+xn]=xml;struct.pack_into('<I',out,xe+28,zlib.crc32(xml));struct.pack_into('<I',out,24,zlib.crc32(out[1024:]));struct.pack_into('<I',out,4,zlib.crc32(out[8:1024]));verify(out)
 for name in ['mbrec.bin','param.bin','sdfs.bin']:
  _,i,size,_,_=p[name];assert out[i:i+size]==b[i:i+size]
 assert out[64:128]==b[64:128]
 profile='v3-display-50-50'+('-arc' if arc else '')+('-center' if center else '')
 folder=R/'candidates'/profile;folder.mkdir(parents=True,exist_ok=True)
 (folder/f'candidate-{profile}.bin').write_bytes(out);(folder/'zephyr-decoded.bin').write_bytes(patched)
 report=dict(profile=profile,hardware_tested=False,source_sha256=hashlib.sha256(b).hexdigest(),candidate_sha256=hashlib.sha256(out).hexdigest(),display_ticks=[50,50],timer_ms=100,nominal_display_seconds=10,arc_guard=arc,arc_condition='mode byte 0xbfc25765 == 5 AND audio-input app pointer 0xbfc24eac != NULL' if arc else None,physical_hpd_not_checked=True,cec_dispatch_unchanged=True,center_positions=21 if center else 11,center_display_range=[-10,10] if center else [-5,5],center_physical_db_not_measured=True,center_saved_legacy_index_not_migrated=center,sw_surr_range_unchanged=True,crc_and_xml_checks_passed=True,boot_params_resources_and_version_unchanged=True,edits=edits)
 (folder/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(profile,report['candidate_sha256'])
if __name__=='__main__':
 build(sys.argv[1]);build(sys.argv[1],arc=True);build(sys.argv[1],arc=True,center=True)

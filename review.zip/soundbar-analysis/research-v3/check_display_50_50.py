"""Bounded interpreter for the actual MIPS16 display timeout slice only.
Not a complete CPU emulator or a hardware/boot test. Unknown instructions fail.
"""
from pathlib import Path
import struct,json
R=Path(__file__).resolve().parent.parent
BASE=0xbf000000;STATE=0xbfc25732;COUNT=0xbfc25730

def tick(code,mem):
 regs={2:mem[STATE],3:0,4:STATE,5:0,6:0};pc=0x49172;t=0
 def reg(n):return regs.get(n,0)
 def branch(w):
  v=w&255;return pc+2+2*(v-256 if v&128 else v)
 for _ in range(60):
  if pc==0x49186:return None
  if pc==0x49124:return reg(4)
  w=struct.unpack_from('<H',code,pc)[0];nextpc=pc+2
  if w==0x7201:t=reg(2)^1
  elif w==0x67b8:regs[5]=t
  elif w==0x2d30:
   if reg(5):nextpc=branch(w)
  elif w in (0xb362,0xb549):
   dest=3 if w==0xb362 else 5;literal=(pc&~3)+4*(w&255);regs[dest]=struct.unpack_from('<I',code,literal)[0]
  elif w==0xab40:regs[2]=mem[reg(3)]
  elif w==0xad60:regs[3]=mem[reg(5)]
  elif w==0x4a01:regs[2]=reg(2)+1
  elif w==0x4b01:regs[3]=reg(3)+1
  elif w==0xea31:regs[2]=reg(2)&65535
  elif w==0xeb31:regs[3]=reg(3)&65535
  elif w&0xff00==0x5a00:t=int(reg(2)<(w&255))
  elif w&0xf800==0xf000:
   q=struct.unpack_from('<H',code,pc+2)[0];assert q&0xff00==0x5b00
   imm=((w&31)<<11)|(w&0x7e0)|(q&31);t=int(reg(3)<imm);nextpc=pc+4
  elif w&0xff00==0x5b00:t=int(reg(3)<(w&255))
  elif w in (0x6023,0x6002):
   if not t:nextpc=branch(w)
  elif w==0xcb40:mem[reg(3)]=reg(2)&65535
  elif w==0xcba0:mem[reg(3)]=reg(5)&65535
  elif w==0xcd60:mem[reg(5)]=reg(3)&65535
  elif w==0xcd40:mem[reg(5)]=reg(2)&65535
  elif w==0xc440:mem[reg(4)]=reg(2)&255
  elif w in (0x6a03,0x6a00):regs[2]=w&255
  elif w==0x6b03:regs[3]=3
  elif w==0xea6e:regs[2]=reg(2)^reg(3)
  elif w==0x2ad4:
   if reg(2):nextpc=branch(w)
  elif w==0x6e00:regs[6]=0
  elif w==0x6d26:regs[5]=38
  elif w in (0x6c06,0x6c07):regs[4]=w&255
  elif w==0x6500:pass
  elif w in (0x17a6,0x1793,0x17cb):
   v=w&2047;nextpc=pc+2+2*(v-2048 if v&1024 else v)
  else:raise AssertionError(f'Unsupported instruction {w:04x} at {pc:x}')
  pc=nextpc
 raise AssertionError('slice did not terminate')

def run(code,expected_off,expected_dim=81):
 mem={STATE:1,COUNT:0};events=[]
 for n in range(1,expected_off+30):
  event=tick(code,mem)
  if event is not None:events.append((n,event))
 assert events==[(expected_dim,6),(expected_off,7)],events
 assert mem[STATE]==0
 # Already dark state must not emit another dim/off command.
 for _ in range(50):assert tick(code,mem) is None
 return events
orig=(R/'decoded/zephyr.bin').read_bytes();original=run(orig,1582)
for profile in ['v3-display-50-50','v3-display-50-50-arc','v3-display-50-50-arc-center']:
 folder=R/'candidates'/profile;patched=(folder/'zephyr-decoded.bin').read_bytes()
 result={'profile':profile,'scope':'actual MIPS16 timeout slice; driver call intercepted, no hardware emulation','original_events_tick_command':original,'patched_events_tick_command':run(patched,100,50),'period_ms':100,'hardware_tested':False}
 (folder/'display-trace.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

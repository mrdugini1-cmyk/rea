"""Bounded MIPS16 instruction checks, not SoC/boot/hardware emulation.
SAVE/RESTORE are modeled as ABI frames. Peripheral writes are intercepted.
Unknown instructions fail rather than being skipped.
"""
from pathlib import Path
import struct,json,sys
R=Path(__file__).resolve().parent.parent;BASE=0xbf000000;END=0x1000000
C=[16,17,2,3,4,5,6,7]
def signed(v,bits):return v-(1<<bits) if v&(1<<(bits-1)) else v
class VM:
 def __init__(self,code):
  self.code=code;self.r=[0x12000000+i for i in range(32)];self.r[29]=0x1ff000;self.r[31]=END|1;self.mem={};self.frames=[];self.calls=[];self.getter=None;self.setter=None;self.pc=0
 def put(self,a,v,n=4):
  for i in range(n):self.mem[a+i]=(v>>(8*i))&255
 def load(self,a,n):
  if BASE<=a and a+n<=BASE+len(self.code):return int.from_bytes(self.code[a-BASE:a-BASE+n],'little')
  return sum(self.mem.get(a+i,0)<<(8*i) for i in range(n))
 def word(self,p):return self.load(p,2)
 def step(self):
  p=self.pc;w=self.word(p);n=p+2;rx=C[(w>>8)&7];ry=C[(w>>5)&7]
  if w in (0x64e3,0x64e4):self.frames.append((self.r[29],self.r[31],self.r[16]));self.r[29]-=8*(w&15)
  elif w in (0x6463,0x6464):self.r[29],self.r[31],self.r[16]=self.frames.pop()
  elif w&0xfc00==0x1800:
   h=((w&31)<<5)|((w>>5)&31);target=((p+4)&0xf0000000)|(((h<<16)|self.word(p+2))<<2)
   self.r[31]=(p+6)|1;self.pc=p+4;self.step()
   if target==0xbf04ea1c:self.calls.append((self.r[6],bytes(self.load(self.r[4]+i,1) for i in range(self.r[5]))));n=self.r[31]&~1
   elif target==0xbf03d084 and self.getter is not None:self.r[2]=self.getter;n=self.r[31]&~1
   elif target==0xbf03d130 and self.getter is not None:self.setter=(self.r[4],self.r[5]);n=END
   else:n=target
  elif w==0xe8a0:n=self.r[31]&~1
  elif w==0xe820:
   target=self.r[31]&~1;self.pc=p+2;self.step();n=target
  elif w==0x6500:pass
  elif w&0xf800==0xb000:self.r[rx]=self.load((p&~3)+4*(w&255),4)
  elif w&0xf800==0x9800:self.r[ry]=self.load(self.r[rx]+4*(w&31),4)
  elif w&0xf800==0xa000:self.r[ry]=self.load(self.r[rx]+(w&31),1)
  elif w&0xf800==0xa800:self.r[ry]=self.load(self.r[rx]+2*(w&31),2)
  elif w&0xf800==0xc000:self.put(self.r[rx]+(w&31),self.r[ry],1)
  elif w&0xf800==0xc800:self.put(self.r[rx]+2*(w&31),self.r[ry],2)
  elif w&0xf800==0x6800:self.r[rx]=w&255
  elif w&0xf800==0x7000:self.r[24]=self.r[rx]^(w&255)
  elif w&0xf800==0x5800:self.r[24]=int(self.r[rx]<(w&255))
  elif w&0xf800==0x4800:self.r[rx]=(self.r[rx]+signed(w&255,8))&0xffffffff
  elif w&0xf800==0x4000:self.r[ry]=(self.r[rx]+signed(w&15,4))&0xffffffff
  elif w&0xf800==0x0000:self.r[rx]=self.r[29]+4*(w&255)
  elif w&0xff00 in (0x6000,0x6100):
   take=(self.r[24]==0) if w&0xff00==0x6000 else (self.r[24]!=0)
   if take:n=p+2+2*signed(w&255,8)
  elif w&0xf800 in (0x2000,0x2800):
   take=(self.r[rx]==0) if w&0xf800==0x2000 else (self.r[rx]!=0)
   if take:n=p+2+2*signed(w&255,8)
  elif w&0xf800==0x1000:n=p+2+2*signed(w&2047,11)
  elif w&0xf8ff==0xe811:self.r[rx]=self.r[rx]&255
  elif w&0xf8ff==0xe831:self.r[rx]=self.r[rx]&65535
  elif w==0xea6e:self.r[2]^=self.r[3]
  elif w==0xe349:self.r[2]=(self.r[3]+self.r[2])&0xffffffff
  elif w==0xe167:self.r[17]=(self.r[17]-self.r[3])&0xffffffff
  elif w in {0x677d,0x675d,0x6744,0x6758,0x6722,0x6702,0x67b0}:
   a,b={0x677d:(3,29),0x675d:(2,29),0x6744:(2,4),0x6758:(2,24),0x6722:(17,2),0x6702:(16,2),0x67b0:(5,16)}[w];self.r[a]=self.r[b]
  else:raise AssertionError(f'unsupported {w:04x} at {p:08x}')
  self.pc=n
 def run(self,start,stops=()):
  self.pc=start
  for _ in range(600):
   if self.pc==END or self.pc in stops:return
   self.step()
  raise AssertionError('did not terminate')

def check_arc(code):
 cases=0
 for mode in range(8):
  for app in [0,0x1ee000]:
   for busy in [0,1]:
    v=VM(code);v.put(0xbfc25765,mode,1);v.put(0xbfc24eac,app);v.put(0xbfc25685,2 if busy else 0,1);before=v.r.copy()
    v.run(0xbf0c69b0);assert v.r[2]==int(bool(busy or (mode==5 and app)))
    for reg in [4,5,6,7,16,17,29,31]:assert v.r[reg]==before[reg],('idle ABI',reg)
    assert not v.frames
    w=VM(code);w.r[3]=0xbfc25736;w.r[6]=1;w.put(0xbfc25736,4799,2);w.put(0xbfc25738,1,1);w.put(0xbfc25765,mode,1);w.put(0xbfc24eac,app);before=w.r.copy()
    w.run(0xbf0c69d0);assert w.r[2]==(0 if mode==5 and app else 4799);assert w.r[5]==0xbfc25738
    for reg in [3,4,6,7,16,17,29,31]:assert w.r[reg]==before[reg],('counter ABI',reg)
    assert not w.frames;cases+=1
 return cases

def check_center(code,extended):
 table_base=struct.unpack_from('<I',code,0x4ee80)[0];table_len=21 if extended else 11;start=0xbf if extended else 0xc9
 for index in range(256):
  v=VM(code);v.r[4]=index;before=v.r.copy();v.run(0xbf04ee44)
  gain=start+2*min(index,table_len-1)
  assert v.calls==[(86,bytes([0x17,gain])),(86,bytes([0x18,gain]))],(index,v.calls)
  for reg in [16,17,29,31]:assert v.r[reg]==before[reg]
  assert not v.frames
 if extended:
  for value in range(1,22):
   for direction in [0,1]:
    v=VM(code);v.getter=value;v.r[4]=direction;v.run(0xbf04e0a8)
    assert v.setter==(3,min(21,value+1) if direction==0 else max(1,value-1)),(value,direction,v.setter)
   v=VM(code);v.r[2]=value;v.run(0xbf048472,stops=(0xbf0483ba,0xbf0483d8,0xbf048422))
   if value<11:assert v.pc==0xbf0483ba and v.r[17]==11-value
   elif value==11:assert v.pc==0xbf0483d8
   else:assert v.pc==0xbf048422 and v.r[17]==value-11
 return dict(driver_inputs=256,registers=[0x17,0x18],table_address=hex(table_base),table_length=table_len,neutral_register_value=0xd3,button_cases=42 if extended else 0,display_values=21 if extended else 0)

def main():
 original=(R/'decoded/zephyr.bin').read_bytes();baseline=check_center(original,False);results=[]
 for profile in ['v3-display-50-50','v3-display-50-50-arc','v3-display-50-50-arc-center']:
  folder=R/'candidates'/profile;code=(folder/'zephyr-decoded.bin').read_bytes();d=json.loads((folder/'verification.json').read_text());result=dict(profile=profile,hardware_tested=False,vm_scope=__doc__.strip(),center_original_baseline=baseline)
  if d['arc_guard']:result['arc_condition_abi_cases']=check_arc(code)
  result['center_checks']=check_center(code,d['center_positions']==21)
  assert code[0x51264:0x512f6]==original[0x51264:0x512f6]
  result['cec_dispatch_byte_identical']=True
  (folder/'instruction-verification.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result)
 print(json.dumps(results,indent=2))
if __name__=='__main__':main()

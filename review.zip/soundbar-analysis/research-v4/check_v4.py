"""Bounded execution of actual instructions. No receiver/hardware emulation."""
from pathlib import Path
import sys,json,runpy
R=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(R/'research-v3'))
import check_v3 as old
class VM(old.VM):
 def step(self):
  p=self.pc;w=self.word(p);rx=old.C[(w>>8)&7];n=p+2
  if w==0x64f6:
   self.frames.append((self.r[29],self.r[31],self.r[16],self.r[17]));self.r[29]-=48
  elif w==0x6476:self.r[29],self.r[31],self.r[16],self.r[17]=self.frames.pop()
  elif w in {0x6703,0x67b1,0x6745,0x6705,0x6791}:
   a,b={0x6703:(16,3),0x67b1:(5,17),0x6745:(2,5),0x6705:(16,5),0x6791:(4,17)}[w];self.r[a]=self.r[b]
  elif w&0xf800==0xf000:
   q=self.word(p+2);imm=((w&31)<<11)|(w&0x7e0)|(q&31);r=old.C[(q>>8)&7]
   if q&0xf800==0x6800:self.r[r]=imm
   elif q&0xf800==0:self.r[r]=self.r[29]+old.signed(imm,16)
   else:raise AssertionError(('extended',hex(p),hex(w),hex(q)))
   n=p+4
  elif w&0xf800==0xd000:self.put(self.r[29]+4*(w&255),self.r[rx])
  elif w&0xf800==0x9000:self.r[rx]=self.load(self.r[29]+4*(w&255),4)
  elif w&0xfc00 in (0x1800,0x1c00):
   h=((w&31)<<5)|((w>>5)&31);target=((p+4)&0xf0000000)|(((h<<16)|self.word(p+2))<<2)
   self.r[31]=(p+6)|1;self.pc=p+4;self.step();n=self.r[31]&~1
   if target==0xbf03d084:self.r[2]=self.getter
   elif target==0xbf03d130:self.setter=(self.r[4],self.r[5])
   elif target==0xbf050800:
    self.packet=bytes([self.r[7]&255]+[self.load(self.r[6]+i,1) for i in range(self.load(self.r[29]+16,4))]);n=old.END
   elif target in (0xbfc236ec,0xbfc23700,0xbf0330c8):self.r[2]=0
   else:raise AssertionError(('call',hex(target),hex(p)))
  else:return super().step()
  self.pc=n
folder=R/'candidates/v4-allranges-experimental';code=(folder/'zephyr-decoded.bin').read_bytes();result={'hardware_tested':False,'receiver_interpretation_tested':False,'scope':__doc__,'arc_cases':old.check_arc(code),'center':old.check_center(code,True),'channels':{}}
for name,fn,ui,idx,reg in [('SW',0x4e01c,0x48438,2,6),('SURR',0x4e110,0x484ac,4,5)]:
 for value in range(1,22):
  for direction in (0,1):
   v=VM(code);v.getter=value;v.r[4]=direction;v.run(old.BASE+fn);expected=min(21,value+1) if direction==0 else max(1,value-1)
   assert v.setter==(idx,expected),(name,value,direction,v.setter)
   assert v.packet==bytes([0x81,reg,(expected-6)&255]),(name,value,direction,v.packet)
  v=VM(code);v.r[2]=value;v.run(old.BASE+ui,stops=(0xbf0483ba,0xbf0483d8,0xbf048422))
  if value<11:assert v.pc==0xbf0483ba and v.r[17]==11-value
  elif value==11:assert v.pc==0xbf0483d8
  else:assert v.pc==0xbf048422 and v.r[17]==value-11
 result['channels'][name]={'button_and_packet_cases':42,'display_values':21}
for value in range(256):
 v=VM(code);v.getter=value;v.run(0xbf04e298);expected=max(1,min(21,value));assert v.packet==bytes([0x81,6,(expected-6)&255]),(value,v.packet)
result['SW_restore_inputs']=256
for logical in range(-5,6):assert ((logical+11-6)&255)==logical+5
result['old_range_commands_preserved']=True
ns=runpy.run_path(str(R/'research-v3/check_display_50_50.py'));result['display_events']=ns['run'](code,100,50)
(folder/'instruction-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

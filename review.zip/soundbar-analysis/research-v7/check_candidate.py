"""Checks final bytes and executes bounded original instruction slices, not hardware."""
from pathlib import Path
import importlib.util,json,struct
D=Path(__file__).resolve().parent;R=D.parent;F=R/'candidates/v5-eq-remote-experimental'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('build3',R/'research-v3/build_v3.py');v=load('vm3',R/'research-v3/check_v3.py')
out=(F/'ota.bin').read_bytes();parts=m.verify(out);_,o,n,_,_=parts['zephyr.bin'];code=m.codec(out[o:o+n]);old=(R/'candidates/v4-allranges-experimental/zephyr-decoded.bin').read_bytes();report=json.loads((F/'verification.json').read_text())
assert code==(F/'zephyr-decoded.bin').read_bytes()
service=int(report['preserved_service_string_address'],16)
assert code[service-0xbf000000:service-0xbf000000+5]==b'tool\0'
for pointer in report['redirected_diagnostic_pointers']:
 assert struct.unpack_from('<I',code,int(pointer['offset'],16))[0]==int(pointer['new'],16)
for literal in [0x1d3e4,0x1d494]:assert struct.unpack_from('<I',code,literal)[0]==service
allowed=bytearray(len(code))
for edit in report['edits']:
 a=int(edit['offset'],16);allowed[a:a+edit['length']]=b'\1'*edit['length']
assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(old,code)))
# Verify actual JAL encodings and the preserved original key argument delay slot.
for at,name in [(0x17ac6,'eq_key_hook'),(0x3d276,'eq_config_init')]:
 assert code[at:at+4]==m.jal(report['symbols'][name]['address']&~1)
assert code[0x17aca:0x17acc]==old[0x17aca:0x17acc]
assert struct.unpack_from('<I',code,0x493c8)[0]==report['symbols']['eq_timer_hook']['address']|1
assert code[0x3d27a:0x3d27c]==bytes.fromhex('0065')
# Reclaimed ranges must not overlap, including any linker string padding.
ranges=[]
for s in report['sections']:
 a=int(s['address'],16)-0xbf000000;ranges.append((a,a+s['size']))
for (a,b),(c,d) in zip(sorted(ranges),sorted(ranges)[1:]):assert b<=c
ns={'__file__':str(R/'research-v3/check_display_50_50.py')};exec((R/'research-v3/check_display_50_50.py').read_text().split('orig=(R/')[0],ns)
result={'scope':__doc__,'display_events_tick_command':ns['run'](code,100,30),'arc_abi_cases':v.check_arc(code),'center':v.check_center(code,True),'hooks_and_delay_slot_verified':True,'key_mapping_unchanged':code[0xa8b98:0xa8f44]==old[0xa8b98:0xa8f44],'cec_unchanged':code[0x51264:0x512f6]==old[0x51264:0x512f6],'all_changes_accounted_for':True,'aota_crc_verified':True,'hardware_tested':False}
(F/'instruction-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

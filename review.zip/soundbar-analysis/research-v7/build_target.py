from pathlib import Path
import subprocess,os,json
R=Path(__file__).resolve().parent;r=R.parent
cc=r/'research-v6/toolchain/root/usr/bin/mipsel-linux-gnu-gcc-14';ccbase=r/'research-v6/toolchain/root/usr/lib/gcc-cross/mipsel-linux-gnu/14'
binpath=r/'binutils/usr/bin';env=dict(os.environ,LD_LIBRARY_PATH=str(r/'binutils/usr/lib/x86_64-linux-gnu'))
report={}
for name in ['eq_core','eq_remote','eq_target']:
 cmd=[str(cc),'-B'+str(ccbase)+'/', '-Os','-mips32','-mips16','-msoft-float','-mno-abicalls','-fno-pic','-G0','-ffreestanding','-fno-builtin','-ffunction-sections','-fdata-sections','-DEQ_FREESTANDING','-Wall','-Wextra','-Werror','-S',str(R/(name+'.c')),'-o',str(R/(name+'.s'))]
 subprocess.run(cmd,check=True)
 subprocess.run([str(binpath/'mipsel-linux-gnu-as'),'-EL','-mips32','-mips16','-msoft-float','-o',str(R/(name+'.o')),str(R/(name+'.s'))],env=env,check=True)
 report[name]=subprocess.check_output([str(binpath/'mipsel-linux-gnu-size'),str(R/(name+'.o'))],env=env,text=True)
print(json.dumps(report,indent=2));(R/'target-sizes.json').write_text(json.dumps(report,indent=2))

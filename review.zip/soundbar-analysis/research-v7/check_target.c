#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define EQ_TARGET_TEST
#include "eq_target.c"
uint8_t *eq_test_root;uint8_t eq_test_original[76],eq_test_mode=5,eq_test_display_state;uint16_t eq_test_display_count;uint8_t eq_test_ui_dirty,eq_test_ui_age;
static uint8_t factory[512],nv[16],last_block[512];static int has_nv,alloc_fail,param_fail,get_fail,flush_fail,small_effect;
static unsigned allocated,dispatches,resets,updates,sets,flushes,timers,draws;static void *player=(void *)0x1000;static const char *app="i2srx_in";static uint32_t uptime_ms=2000;
void *target_alloc(unsigned n){allocated++;return alloc_fail?NULL:malloc(n);}
void *target_memset(void *p,int c,unsigned n){return memset(p,c,n);}
void *target_player(void){return player;}
const char *target_app(void){return app;}
int target_param(void *p,int id,const void *data,unsigned n){assert(p==player&&id==12&&n==512);if(param_fail)return -1;memcpy(last_block,data,512);updates++;return 0;}
const uint8_t *target_effect(unsigned stream,unsigned effect,int *size){assert(stream==14&&effect==0);*size=small_effect?20:512;return factory;}
int target_get(const char *key,void *out,unsigned n){assert(!strcmp(key,"USER_PEQ5")&&n==16);if(!has_nv||get_fail)return -1;memcpy(out,nv,16);return 16;}
int target_set(const char *key,const void *in,unsigned n){assert(!strcmp(key,"USER_PEQ5")&&n==16);memcpy(nv,in,16);has_nv=1;sets++;return 0;}
int target_flush(const char *key){assert(!strcmp(key,"USER_PEQ5"));flushes++;return flush_fail?-1:0;}
void target_draw(unsigned pos,unsigned glyph,unsigned enabled){assert(pos<4&&glyph<42&&enabled<2);draws++;}
uint32_t target_uptime(void){return uptime_ms;}
int target_dispatch(uint32_t raw){dispatches++;if((raw&65535)==EQ_KEY_CODE&&(raw&0xffff0000UL)==KEY_LONG)resets++;return 123;}
void target_timer(void *arg){assert(arg==(void *)0x7770);timers++;}
static void key(uint32_t raw){uptime_ms+=200;eq_key_hook(raw);}
static void tick(void){uptime_ms+=100;eq_timer_hook((void *)0x7770);}
int main(int argc,char **argv){
 FILE *f;eq_runtime *t;uint8_t before[76];unsigned n,u,old_alloc;
 assert(argc==2);f=fopen(argv[1],"rb");assert(f&&fread(factory,1,512,f)==512);fclose(f);
 memset(eq_test_original,0xaa,76);alloc_fail=1;eq_config_init(eq_test_original,0,76);assert(eq_test_root==eq_test_original&&!runtime());
 n=dispatches;key(KEY_LONG|EQ_KEY_CODE);assert(dispatches==n&&resets==0);
 key(KEY_SHORT_UP|EQ_KEY_CODE);assert(dispatches==n+1);
 alloc_fail=0;eq_config_init(eq_test_original,0,76);t=runtime();assert(t&&eq_test_root!=eq_test_original);for(n=0;n<76;n++)assert(!eq_test_root[n]);
 memset(eq_test_root,0x5a,76);memcpy(before,eq_test_root,76);tick();assert(!updates&&!sets&&!t->editor.editing);
 key(KEY_LONG|EQ_KEY_CODE);assert(t->editor.editing&&updates==1&&resets==0);
 key(KEY_SHORT_UP|EQ_KEY_CODE);assert(t->editor.editing&&!sets);
 key(KEY_SHORT_UP|GEAR_KEY_CODE);assert(t->editor.band==1);
 key(KEY_SHORT_UP|PLUS_KEY_CODE);assert(t->editor.draft[1]==1&&last_block[52+8*5]==10);
 n=dispatches;key(KEY_SHORT_UP|2);key(KEY_SHORT_UP|3);key(KEY_SHORT_UP|5);key(KEY_SHORT_UP|6);assert(dispatches==n+4&&t->editor.band==1&&t->editor.draft[1]==1);
 eq_test_display_count=99;tick();assert(eq_test_display_count==0&&eq_test_display_state==1&&draws>=4);
 key(KEY_SHORT_DOWN|EQ_KEY_CODE);key(KEY_SHORT_UP|EQ_KEY_CODE);assert(!t->editor.editing&&sets==1&&flushes==1&&t->configured);
 n=dispatches;key(KEY_SHORT_UP|EQ_KEY_CODE);assert(dispatches==n+1);
 assert(!memcmp(before,eq_test_root,76));
 old_alloc=allocated;eq_config_init(eq_test_original,0,76);t=runtime();assert(t&&allocated==old_alloc);u=updates;tick();assert(t->configured&&t->editor.saved[1]==1&&updates==u+1&&sets==1);
 key(KEY_LONG|EQ_KEY_CODE);key(KEY_LONG_UP|EQ_KEY_CODE);key(KEY_SHORT_UP|PLUS_KEY_CODE);assert(t->editor.editing);
 u=updates;player=(void *)0x2000;tick();assert(!t->editor.editing&&t->player==player&&updates>=u);
 app="enter";player=0;u=updates;n=draws;tick();assert(!t->editor.editing&&updates==u&&draws==n);
 app="btcall";player=(void *)0x3000;u=updates;tick();assert(updates==u);
 app="i2srx_in";player=(void *)0x4000;tick();key(KEY_LONG|EQ_KEY_CODE);assert(t->editor.editing);key(KEY_SHORT_UP|EQ_KEY_CODE);
 flush_fail=1;key(KEY_SHORT_UP|EQ_KEY_CODE);assert(!t->editor.editing&&t->error);flush_fail=0;
 /* No actual writes to flash, ARC transport or physical display occur here. */
 assert(resets==0);printf("target adapter simulation passed; allocations=%u updates=%u property_sets=%u stock_dispatches=%u original_timer_calls=%u\n",allocated,updates,sets,dispatches,timers);
 return 0;
}

"""Read-only AOTA extraction and Actions 32-byte scrambler investigation.
Scrambler feedback taps are adapted from Eugene Smith's MIT-licensed
ats2819-notes/tools/norline.py; see that repository's LICENSE.
No flashing or application patches are implemented here.
"""
from pathlib import Path
import hashlib,struct,zlib,json,importlib.util
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('norline',ROOT/'ats2819-notes/tools/norline.py')
norline=importlib.util.module_from_spec(spec);spec.loader.exec_module(norline)
KEY=bytes.fromhex('a1662b968ae2403342a4ed7b31e5bf9ad69be2637003c5ff7bd173457a90d52a')
def transform(data,encode=False):
 out=bytearray()
 for base in range(0,len(data),32):
  history=[]
  for k,v in enumerate(data[base:base+32]):
   plain=v if encode else v^KEY[k]^norline._keystream_byte(history,k)
   out.append(v^KEY[k]^norline._keystream_byte(history,k))
   history.append((plain&0x3c).bit_count()&1)
 return bytes(out)
def main(path):
 b=Path(path).read_bytes();assert b[:4]==b'AOTA'
 assert zlib.crc32(b[8:1024])==struct.unpack_from('<I',b,4)[0]
 assert zlib.crc32(b[1024:])==struct.unpack_from('<I',b,24)[0]
 entries=[];count=struct.unpack_from('<H',b,12)[0];out=ROOT/'decoded';out.mkdir(exist_ok=True)
 for n in range(count):
  pos=512+32*n;name=b[pos:pos+16].split(b'\0')[0].decode('ascii')
  assert Path(name).name==name
  start,size,_,crc=struct.unpack_from('<4I',b,pos+16);assert start+size<=len(b)
  raw=b[start:start+size];assert zlib.crc32(raw)==crc
  data=raw if name=='ota.xml' else transform(raw)
  if name!='ota.xml':assert transform(data,True)==raw
  (out/name).write_bytes(data)
  entries.append(dict(name=name,offset=start,size=size,crc32=hex(crc),roundtrip_identical=True,decoded_sha256=hashlib.sha256(data).hexdigest()))
 report=dict(input_sha256=hashlib.sha256(b).hexdigest(),container_crc_valid=True,entries=entries,note='Codec roundtrip and container CRCs do not prove decoded code correctness or bootability. No modifications made.')
 (ROOT/'verified-extraction.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':
 import sys
 main(sys.argv[1])

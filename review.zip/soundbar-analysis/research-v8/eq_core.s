	.file	1 "eq_core.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.text.copy_gain,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	copy_gain
	.type	copy_gain, @function
copy_gain:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0
$L2:
	addu	$3,$5,$2
	lb	$6,0($3)
	addu	$3,$4,$2
	addiu	$2,1
	cmpi	$2,5
	sb	$6,0($3)
	btnez	$L2
	jr	$31
	.end	copy_gain
	.size	copy_gain, .-copy_gain
	.section	.text.cancel,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	cancel
	.type	cancel, @function
cancel:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	save	24,$16,$31
	move	$7,$5
	move	$16,$4
	beqz	$5,$L4
	lw	$2,28($4)
	li	$7,0
	beqz	$2,$L4
	move	$5,$4
	.set	noreorder
	.set	nomacro
	jalr	$2
	lw	$4,24($4)
	.set	macro
	.set	reorder

	move	$7,$2
$L4:
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	copy_gain
	addiu	$4,$16,5
	.set	macro
	.set	reorder

	li	$2,0
	sb	$2,10($16)
	li	$2,1
	beqz	$7,$L3
	addiu	$2,-2
$L3:
	restore	24,$16,$31
	jr	$31
	.end	cancel
	.size	cancel, .-cancel
	.section	.text.settings_crc,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	settings_crc
	.type	settings_crc, @function
settings_crc:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	addiu	$6,$4,7
	addiu	$6,7
	li	$2,65535
$L16:
	lbu	$3,0($4)
	sll	$3,$3,8
	xor	$2,$3
	zeh	$2
	li	$3,8
$L15:
	seh	$2
	sll	$5,$2,1
	slt	$2,0
	seh	$5
	li	$2,0
	bteqz	$L14
	li	$2,4129
$L14:
	xor	$2,$5
	addiu	$3,-1
	zeh	$2
	bnez	$3,$L15
	addiu	$4,1
	cmp	$6,$4
	btnez	$L16
	jr	$31
	.end	settings_crc
	.size	settings_crc, .-settings_crc
	.section	.text.eq_make_block,"ax",@progbits
	.align	2
	.globl	eq_make_block
	.set	mips16
	.set	nomicromips
	.ent	eq_make_block
	.type	eq_make_block, @function
eq_make_block:
	.frame	$sp,32,$31		# vars= 24, regs= 2/0, args= 0, gp= 0
	.mask	0x00030000,-4
	.fmask	0x00000000,0
	beqz	$4,$L32
	move	$25,$5
	beqz	$5,$L32
	beqz	$6,$L32
	cmp	$4,$6
	bteqz	$L32
	lbu	$2,1($4)
	lbu	$3,0($4)
	sll	$2,$2,8
	or	$3,$2
	cmpi	$3,1
	btnez	$L32
	lbu	$2,5($4)
	lbu	$3,4($4)
	sll	$2,$2,8
	or	$2,$3
	sltu	$2,601
	bteqz	$L32
	save	32,$16,$17
	lw	$3,$L44
	li	$5,0
	sw	$3,0($sp)
$L21:
	lw	$3,$L45
	sw	$3,16($sp)
	addu	$3,$5,$3
	lbu	$7,0($3)
	sll	$3,$7,3
	sll	$7,$7,1
	addu	$7,$4,$7
	lbu	$16,8($7)
	lbu	$7,9($7)
	addiu	$3,48
	sll	$7,$7,8
	or	$7,$16
	sw	$7,12($sp)
	move	$7,$25
	addu	$3,$4,$3
	addu	$7,$7,$5
	lb	$16,0($7)
	lbu	$7,4($3)
	move	$24,$7
	lbu	$7,5($3)
	move	$17,$24
	sll	$7,$7,8
	or	$7,$17
	sll	$17,$16,2
	addu	$17,$17,$16
	sll	$17,$17,1
	seh	$7
	addu	$7,$7,$17
	sw	$7,8($sp)
	addiu	$7,$16,6
	zeb	$7
	sltu	$7,13
	sw	$17,4($sp)
	bteqz	$L39
	lw	$17,0($sp)
	lbu	$7,0($3)
	lhu	$17,0($17)
	sw	$7,20($sp)
	lbu	$7,1($3)
	move	$24,$17
	lw	$17,20($sp)
	sll	$7,$7,8
	or	$7,$17
	move	$17,$24
	cmp	$17,$7
	btnez	$L39
	lbu	$7,2($3)
	move	$24,$7
	lbu	$7,3($3)
	move	$17,$24
	sll	$7,$7,8
	or	$7,$17
	cmpi	$7,7
	btnez	$L39
	lbu	$7,6($3)
	lbu	$3,7($3)
	sll	$3,$3,8
	or	$3,$7
	cmpi	$3,1
	btnez	$L39
	lw	$3,12($sp)
	sltu	$3,3
	bteqz	$L39
	lw	$3,8($sp)
	addiu	$3,127
	addiu	$3,113
	sltu	$3,361
	bteqz	$L39
	slt	$16,1
	btnez	$L20
	lw	$3,4($sp)
	addu	$2,$2,$3
	zeh	$2
$L20:
	lw	$3,0($sp)
	addiu	$5,1
	addiu	$3,2
	cmpi	$5,5
	sw	$3,0($sp)
	btnez	$L21
	sltu	$2,601
	bteqz	$L39
	li	$3,0
$L22:
	addu	$5,$4,$3
	lbu	$7,0($5)
	addu	$5,$6,$3
	addiu	$3,1
	cmpi	$3,512
	sb	$7,0($5)
	btnez	$L22
	sb	$2,4($6)
	srl	$2,$2,8
	sb	$2,5($6)
	li	$5,0
$L26:
	move	$2,$25
	addu	$2,$2,$5
	lb	$16,0($2)
	beqz	$16,$L24
	lw	$2,16($sp)
	addu	$2,$2,$5
	lbu	$3,0($2)
	sll	$2,$3,3
	addiu	$2,52
	addu	$7,$6,$2
	addu	$2,$4,$2
	lbu	$17,0($2)
	lbu	$2,1($2)
	sll	$3,$3,1
	sll	$2,$2,8
	or	$2,$17
	sll	$17,$16,2
	addu	$16,$16,$17
	sll	$16,$16,1
	addu	$2,$2,$16
	zeh	$2
	sb	$2,0($7)
	addiu	$3,8
	srl	$2,$2,8
	sb	$2,1($7)
	addu	$2,$4,$3
	lbu	$7,0($2)
	lbu	$2,1($2)
	sll	$2,$2,8
	or	$2,$7
	bnez	$2,$L24
	addu	$3,$6,$3
	li	$7,1
	sb	$7,0($3)
	sb	$2,1($3)
$L24:
	addiu	$5,1
	cmpi	$5,5
	btnez	$L26
	li	$2,0
$L18:
	restore	32,$16,$17
	jr	$31
$L32:
	li	$2,1
	.set	noreorder
	.set	nomacro
	jr	$31
	neg	$2,$2
	.set	macro
	.set	reorder

$L39:
	li	$2,1
	neg	$2,$2
	b	$L18
	.type	__pool_eq_make_block_44, @object
__pool_eq_make_block_44:
	.align	2
$L44:
	.word	eq_frequencies
$L45:
	.word	slots
	.type	__pend_eq_make_block_44, @object
__pend_eq_make_block_44:
	.end	eq_make_block
	.size	eq_make_block, .-eq_make_block
	.section	.text.eq_editor_init,"ax",@progbits
	.align	2
	.globl	eq_editor_init
	.set	mips16
	.set	nomicromips
	.ent	eq_editor_init
	.type	eq_editor_init, @function
eq_editor_init:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0
	sw	$2,0($4)
	sw	$2,4($4)
	sw	$2,8($4)
	sb	$2,12($4)
	sw	$2,16($4)
	sw	$2,20($4)
	sw	$5,24($4)
	sw	$6,28($4)
	.set	noreorder
	.set	nomacro
	jr	$31
	sw	$7,32($4)
	.set	macro
	.set	reorder

	.end	eq_editor_init
	.size	eq_editor_init, .-eq_editor_init
	.section	.text.eq_editor_event,"ax",@progbits
	.align	2
	.globl	eq_editor_event
	.set	mips16
	.set	nomicromips
	.ent	eq_editor_event
	.type	eq_editor_event, @function
eq_editor_event:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	$4-$7,48,$16,$17,$31
	move	$17,$4
	lbu	$4,10($4)
	move	$2,$5
	move	$16,$6
	beqz	$4,$L48
	lw	$4,20($17)
	li	$5,0
	xor	$4,$7
	bnez	$4,$L83
	cmpi	$2,8
	btnez	$L80
	li	$5,1
$L83:
	.set	noreorder
	.set	nomacro
	jal	cancel
	move	$4,$17
	.set	macro
	.set	reorder

$L50:
	li	$2,0
$L47:
	restore	48,$16,$17,$31
	jr	$31
$L56:
	cmpi	$2,6
	sw	$16,16($17)
	bteqz	$L86
	cmpi	$2,5
	btnez	$L59
	lw	$2,32($17)
	beqz	$2,$L61
	lw	$4,24($17)
	addiu	$16,$17,5
	.set	noreorder
	.set	nomacro
	jalr	$2
	move	$5,$16
	.set	macro
	.set	reorder

	move	$7,$2
	beqz	$2,$L79
$L61:
	li	$5,1
	.set	noreorder
	.set	nomacro
	jal	cancel
	move	$4,$17
	.set	macro
	.set	reorder

$L53:
	li	$2,1
	neg	$2,$2
	b	$L47
$L79:
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	copy_gain
	move	$4,$17
	.set	macro
	.set	reorder

	sb	$7,10($17)
	b	$L55
$L59:
	cmpi	$2,2
	move	$4,$24
	bnez	$4,$L64
	lbu	$2,11($17)
	sb	$4,12($17)
	addiu	$2,1
$L84:
	li	$4,5
	divu	$0,$2,$4
	bnez	$4,1f
	break	7
1:
	mfhi	$2
	sb	$2,11($17)
	b	$L55
$L64:
	cmpi	$2,1
	move	$4,$24
	bnez	$4,$L65
	lbu	$2,11($17)
	sb	$4,12($17)
	addiu	$2,4
	b	$L84
$L65:
	addiu	$4,$2,-3
	sltu	$4,2
	bteqz	$L50
	sw	$2,52($sp)
	li	$4,1
	addiu	$2,$17,5
	addiu	$16,$sp,16
	move	$5,$2
	sb	$4,12($17)
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jal	copy_gain
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	lbu	$5,11($17)
	lw	$2,52($sp)
	addu	$4,$16,$5
	cmpi	$2,3
	lb	$4,0($4)
	btnez	$L66
	slt	$4,6
	addiu	$4,1
	bteqz	$L55
$L85:
	seb	$4
	addu	$5,$16,$5
	sb	$4,0($5)
	lw	$2,28($17)
	lw	$4,24($17)
	.set	noreorder
	.set	nomacro
	jalr	$2
	move	$5,$16
	.set	macro
	.set	reorder

	bnez	$2,$L61
	lw	$4,24($sp)
	.set	noreorder
	.set	nomacro
	jal	copy_gain
	move	$5,$16
	.set	macro
	.set	reorder

	b	$L55
$L66:
	slt	$4,-5
	btnez	$L55
	addiu	$4,-1
	b	$L85
$L48:
	cmpi	$5,8
	bteqz	$L50
	bnez	$5,$L50
	lw	$2,28($17)
	beqz	$2,$L53
	lw	$4,24($17)
	.set	noreorder
	.set	nomacro
	jalr	$2
	move	$5,$17
	.set	macro
	.set	reorder

	move	$7,$2
	bnez	$2,$L53
	move	$5,$17
	.set	noreorder
	.set	nomacro
	jal	copy_gain
	addiu	$4,$17,5
	.set	macro
	.set	reorder

	li	$2,1
	sh	$2,10($17)
	lw	$2,60($sp)
	sb	$7,12($17)
	sw	$2,20($17)
$L71:
	sw	$16,16($17)
$L55:
	li	$2,1
	b	$L47
$L80:
	beqz	$2,$L71
	cmpi	$2,7
	btnez	$L56
	lw	$2,16($17)
	subu	$16,$16,$2
	sltu	$16,15000
	btnez	$L50
$L86:
	li	$5,1
	.set	noreorder
	.set	nomacro
	jal	cancel
	move	$4,$17
	.set	macro
	.set	reorder

	b	$L47
	.end	eq_editor_event
	.size	eq_editor_event, .-eq_editor_event
	.section	.text.eq_settings_encode,"ax",@progbits
	.align	2
	.globl	eq_settings_encode
	.set	mips16
	.set	nomicromips
	.ent	eq_settings_encode
	.type	eq_settings_encode, @function
eq_settings_encode:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	beqz	$4,$L94
	move	$7,$5
	beqz	$5,$L94
	addiu	$5,$4,5
	move	$3,$4
$L89:
	lbu	$2,0($3)
	addiu	$2,6
	zeb	$2
	sltu	$2,13
	bteqz	$L94
	addiu	$3,1
	cmp	$3,$5
	btnez	$L89
	addiu	$3,$7,7
	move	$2,$7
	addiu	$3,9
	save	24,$31
$L90:
	li	$6,0
	sb	$6,0($2)
	addiu	$2,1
	cmp	$2,$3
	btnez	$L90
	li	$2,84
	sb	$2,0($7)
	li	$2,69
	sb	$2,1($7)
	li	$2,81
	sb	$2,2($7)
	li	$2,49
	sb	$2,3($7)
	li	$2,1
	sb	$2,4($7)
	li	$2,5
	sb	$2,5($7)
	li	$2,6
	sb	$2,6($7)
	addiu	$2,$7,7
	addiu	$2,1
$L91:
	lbu	$3,0($4)
	addiu	$4,1
	cmp	$4,$5
	sb	$3,0($2)
	addiu	$2,1
	btnez	$L91
	.set	noreorder
	.set	nomacro
	jal	settings_crc
	move	$4,$7
	.set	macro
	.set	reorder

	sb	$2,14($7)
	srl	$2,$2,8
	sb	$2,15($7)
	restore	24,$31
	.set	noreorder
	.set	nomacro
	jr	$31
	li	$2,0
	.set	macro
	.set	reorder

$L94:
	li	$2,1
	.set	noreorder
	.set	nomacro
	jr	$31
	neg	$2,$2
	.set	macro
	.set	reorder

	.end	eq_settings_encode
	.size	eq_settings_encode, .-eq_settings_encode
	.section	.text.eq_settings_decode,"ax",@progbits
	.align	2
	.globl	eq_settings_decode
	.set	mips16
	.set	nomicromips
	.ent	eq_settings_decode
	.type	eq_settings_decode, @function
eq_settings_decode:
	.frame	$sp,32,$31		# vars= 0, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	beqz	$4,$L103
	save	32,$16,$17,$31
	move	$16,$5
	beqz	$5,$L116
	lbu	$2,0($4)
	move	$7,$4
	cmpi	$2,84
	btnez	$L116
	lbu	$2,1($4)
	cmpi	$2,69
	btnez	$L116
	lbu	$2,2($4)
	cmpi	$2,81
	btnez	$L116
	lbu	$2,3($4)
	cmpi	$2,49
	btnez	$L116
	lbu	$2,4($4)
	cmpi	$2,1
	btnez	$L116
	lbu	$2,5($4)
	cmpi	$2,5
	btnez	$L116
	lbu	$2,6($4)
	cmpi	$2,6
	btnez	$L116
	lbu	$2,7($4)
	bnez	$2,$L116
	lbu	$2,13($4)
	bnez	$2,$L116
	lbu	$17,15($4)
	lbu	$2,14($4)
	sll	$17,$17,8
	.set	noreorder
	.set	nomacro
	jal	settings_crc
	or	$17,$2
	.set	macro
	.set	reorder

	xor	$2,$17
	bnez	$2,$L116
	addiu	$2,$7,7
	addiu	$2,1
	addiu	$7,13
	move	$3,$2
$L101:
	lb	$4,0($3)
	slt	$4,-6
	btnez	$L116
	slt	$4,7
	bteqz	$L116
	addiu	$3,1
	cmp	$3,$7
	btnez	$L101
$L102:
	lbu	$3,0($2)
	addiu	$2,1
	cmp	$2,$7
	sb	$3,0($16)
	addiu	$16,1
	btnez	$L102
	li	$2,0
$L99:
	restore	32,$16,$17,$31
	jr	$31
$L103:
	li	$2,1
	.set	noreorder
	.set	nomacro
	jr	$31
	neg	$2,$2
	.set	macro
	.set	reorder

$L116:
	li	$2,1
	neg	$2,$2
	b	$L99
	.end	eq_settings_decode
	.size	eq_settings_decode, .-eq_settings_decode
	.section	.text.eq_display_frame,"ax",@progbits
	.align	2
	.globl	eq_display_frame
	.set	mips16
	.set	nomicromips
	.ent	eq_display_frame
	.type	eq_display_frame, @function
eq_display_frame:
	.frame	$sp,8,$31		# vars= 0, regs= 1/0, args= 0, gp= 0
	.mask	0x00010000,-4
	.fmask	0x00000000,0
	li	$2,0
	beqz	$4,$L144
	beqz	$6,$L144
	beqz	$7,$L144
	lbu	$3,10($4)
	beqz	$3,$L144
	lbu	$2,11($4)
	sltu	$2,5
	bteqz	$L134
	save	8,$16
	addu	$2,$4,$2
	lb	$3,5($2)
	move	$2,$3
	zeb	$2
	addiu	$16,$2,6
	zeb	$16
	sltu	$16,13
	bteqz	$L135
	lw	$16,16($4)
	subu	$5,$5,$16
	li	$16,1800
	divu	$0,$5,$16
	bnez	$16,1f
	break	7
1:
	lbu	$16,12($4)
	mfhi	$5
	beqz	$16,$L123
	sltu	$5,1200
$L124:
	btnez	$L129
	li	$2,0
$L125:
	lbu	$5,11($4)
	lw	$3,$L142
	sll	$5,$5,2
	addu	$3,$3,$5
	addu	$3,$3,$2
	lbu	$3,0($3)
	addu	$16,$6,$2
	sb	$3,0($16)
	lbu	$5,11($4)
	lw	$3,$L143
	sll	$5,$5,2
	addu	$3,$3,$5
	addu	$3,$3,$2
	addu	$16,$7,$2
	lbu	$3,0($3)
	addiu	$2,1
	cmpi	$2,4
	sb	$3,0($16)
	btnez	$L125
$L128:
	li	$2,1
$L121:
	restore	8,$16
	jr	$31
$L123:
	sltu	$5,600
	move	$5,$24
	cmpi	$5,1
	b	$L124
$L129:
	slt	$3,0
	move	$5,$24
	li	$4,14
	sltu	$5,1
	sb	$4,0($6)
	move	$4,$24
	addiu	$4,40
	sb	$4,1($6)
	li	$4,0
	sb	$4,2($6)
	beqz	$5,$L127
	neg	$2,$2
	zeb	$2
$L127:
	sltu	$3,1
	move	$3,$24
	cmpi	$3,1
	sb	$2,3($6)
	move	$3,$24
	li	$2,1
	sb	$2,0($7)
	sb	$3,1($7)
	sb	$2,2($7)
	sb	$2,3($7)
	b	$L128
$L134:
	li	$2,1
	.set	noreorder
	.set	nomacro
	jr	$31
	neg	$2,$2
	.set	macro
	.set	reorder

$L135:
	li	$2,1
	neg	$2,$2
	b	$L121
$L144:
	jr	$31
	.type	__pool_eq_display_frame_142, @object
__pool_eq_display_frame_142:
	.align	2
$L142:
	.word	labels.1
$L143:
	.word	masks.0
	.type	__pend_eq_display_frame_142, @object
__pend_eq_display_frame_142:
	.end	eq_display_frame
	.size	eq_display_frame, .-eq_display_frame
	.section	.rodata.masks.0,"a"
	.align	2
	.type	masks.0, @object
	.size	masks.0, 20
masks.0:
	.ascii	"\000\001\001\001"
	.ascii	"\001\001\001\001"
	.ascii	"\000\001\001\000"
	.ascii	"\000\001\001\000"
	.ascii	"\001\001\001\000"
	.section	.rodata.labels.1,"a"
	.align	2
	.type	labels.1, @object
	.size	labels.1, 20
labels.1:
	.ascii	"\000\000\006\003"
	.ascii	"\000\002\005\000"
	.ascii	"\000\001\024\000"
	.ascii	"\000\004\024\000"
	.ascii	"\001\006\024\000"
	.section	.rodata.slots,"a"
	.align	2
	.type	slots, @object
	.size	slots, 5
slots:
	.ascii	"\002\005\007\012\015"
	.globl	eq_frequencies
	.section	.rodata.eq_frequencies,"a"
	.align	2
	.type	eq_frequencies, @object
	.size	eq_frequencies, 10
eq_frequencies:
	.half	63
	.half	250
	.half	1000
	.half	4000
	.half	16000
	.ident	"GCC: (Debian 14.2.0-13) 14.2.0"
	.section	.note.GNU-stack,"",@progbits

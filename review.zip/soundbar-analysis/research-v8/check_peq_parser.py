"""Execute the original PEQ selection/copy slice; coefficient calculation and audio are not emulated."""
from pathlib import Path
import importlib.util,struct,json
R=Path(__file__).resolve().parent.parent;sp=importlib.util.spec_from_file_location('vm',R/'research-v3/check_v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
class VM(m.VM):
 def step(self):
  p=self.pc;w=self.word(p)
  if w&0xf800==0xf000:
   q=self.word(p+2);imm=((w&31)<<11)|(w&0x7e0)|(q&31);rx=m.C[(q>>8)&7];ry=m.C[(q>>5)&7]
   if q&0xf800==0xb000:self.r[rx]=self.load((p&~3)+imm,4)
   elif q&0xf800==0x8800:self.r[ry]=m.signed(self.load(self.r[rx]+m.signed(imm,16),2),16)&0xffffffff
   else:raise AssertionError((hex(p),hex(w),hex(q)))
   self.pc+=4;return
  if w&0xf800==0x9000:self.r[m.C[(w>>8)&7]]=self.load(self.r[29]+4*(w&255),4);self.pc+=2;return
  if w&0xf800==0x8800:self.r[m.C[(w>>5)&7]]=m.signed(self.load(self.r[m.C[(w>>8)&7]]+2*(w&31),2),16)&0xffffffff;self.pc+=2;return
  moves={0x6707:(16,7),0x6767:(3,7),0x651b:(24,3),0x6707:(16,7)}
  if w in moves:a,b=moves[w];self.r[a]=self.r[b];self.pc+=2;return
  if w in [0xebb1,0xeab1]:r={0xebb1:3,0xeab1:2}[w];self.r[r]=m.signed(self.r[r]&65535,16)&0xffffffff;self.pc+=2;return
  if w==0x324c:self.r[2]=(self.r[2]<<3)&0xffffffff;self.pc+=2;return
  if w==0x3367:self.r[3]=(m.signed(self.r[3],32)>>1)&0xffffffff;self.pc+=2;return
  if w==0xe2f1:self.r[4]=(self.r[2]+self.r[7])&0xffffffff;self.pc+=2;return
  if w==0xe35f:self.r[7]=(self.r[3]-self.r[2])&0xffffffff;self.pc+=2;return
  if w in [0xea62,0xe9e2]:a,b={0xea62:(2,3),0xe9e2:(17,7)}[w];self.r[24]=int(m.signed(self.r[a],32)<m.signed(self.r[b],32));self.pc+=2;return
  return super().step()
def parse(code,raw):
 v=VM(code);base=0x100000;ctx=struct.unpack_from('<I',code,0x95e0)[0]
 for j,b in enumerate(raw):v.put(base+j,b,1)
 v.put(v.r[29]+72,base);v.put(v.r[29]+76,base+8);v.put(ctx,48000);v.put(ctx+46,0,2);v.r[2]=19;v.r[17]=0
 v.pc=0xbf008e6a
 for _ in range(2000):
  if v.pc==0xbf008eda:break
  v.step()
 else:raise AssertionError('copy loop did not finish')
 expected=[]
 for slot in range(20):
  rec=struct.unpack_from('<4h',raw,48+8*slot);route=struct.unpack_from('<h',raw,8+2*slot)[0]
  if route==1 and 0<=rec[0]<24000 and (rec[3]!=1 or rec[2]!=0):expected.append(rec)
 actual=[tuple(m.signed(v.load(ctx+50+8*i+2*j,2),16) for j in range(4)) for i in range(len(expected))]
 assert actual==expected,(actual,expected)
 return actual
if __name__=='__main__':
 code=(R/'decoded/zephyr.bin').read_bytes();factory=(R/'decoded/resources/music.efx').read_bytes()[:512];checks=[]
 for slot in [2,5,7,10,13]:
  for gain in [-60,-10,10,60]:
   raw=bytearray(factory);struct.pack_into('<h',raw,8+2*slot,1);struct.pack_into('<h',raw,52+8*slot,gain);actual=parse(code,raw);assert any(x[0]==struct.unpack_from('<h',raw,48+8*slot)[0] and x[2]==gain for x in actual);checks.append(dict(slot=slot,gain_tenths_db=gain))
 result=dict(scope=__doc__,cases=len(checks),field_offsets=dict(routes=8,records=48,record_stride=8,gain_in_record=4),max_slots=20,source_sdk_format_consistent=True,physical_arc_response_verified=False)
 (R/'research-v6/peq-parser-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

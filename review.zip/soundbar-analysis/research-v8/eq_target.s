	.file	1 "eq_target.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.text.runtime,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	runtime
	.type	runtime, @function
runtime:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	lw	$2,$L8
	lw	$2,0($2)
	beqz	$2,$L11
	lw	$3,$L9
	xor	$3,$2
	beqz	$3,$L4
	lw	$3,$L10
	lw	$4,76($2)
	xor	$3,$4
	bnez	$3,$L4
	.set	noreorder
	.set	nomacro
	jr	$31
	addiu	$2,76
	.set	macro
	.set	reorder

$L4:
	li	$2,0
$L11:
	jr	$31
	.type	__pool_runtime_8, @object
__pool_runtime_8:
	.align	2
$L8:
	.word	-1077780540
$L9:
	.word	-1077780616
$L10:
	.word	1363490097
	.type	__pend_runtime_8, @object
__pend_runtime_8:
	.end	runtime
	.size	runtime, .-runtime
	.section	.text.error,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	error
	.type	error, @function
error:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	li	$2,1
	save	24,$16,$31
	sb	$2,24($4)
	lw	$2,$L14
	.set	noreorder
	.set	nomacro
	jalr	$2
	move	$16,$4
	.set	macro
	.set	reorder

	sw	$2,12($16)
	restore	24,$16,$31
	jr	$31
	.type	__pool_error_14, @object
__pool_error_14:
	.align	2
$L14:
	.word	-1089979031
	.type	__pend_error_14, @object
__pend_error_14:
	.end	error
	.size	error, .-error
	.section	.text.save,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	save
	.type	save, @function
save:
	.frame	$sp,64,$31		# vars= 32, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	64,$16,$17,$31
	move	$17,$4
	move	$4,$5
	.set	noreorder
	.set	nomacro
	jal	eq_settings_encode
	addiu	$5,$sp,32
	.set	macro
	.set	reorder

	bnez	$2,$L17
	move	$16,$2
	lw	$2,$L22
	li	$6,16
	lw	$4,$L23
	.set	noreorder
	.set	nomacro
	jalr	$2
	addiu	$5,$sp,32
	.set	macro
	.set	reorder

	slt	$2,0
	btnez	$L17
	lw	$2,$L24
	lw	$4,$L23
	jalr	$2
	slt	$2,0
	btnez	$L17
	lw	$2,$L25
	li	$6,16
	lw	$4,$L23
	.set	noreorder
	.set	nomacro
	jalr	$2
	addiu	$5,$sp,16
	.set	macro
	.set	reorder

	cmpi	$2,16
	li	$2,0
	bteqz	$L19
$L17:
	move	$4,$17
	.set	noreorder
	.set	nomacro
	jal	error
	li	$16,1
	.set	macro
	.set	reorder

	neg	$16,$16
$L15:
	move	$2,$16
	restore	64,$16,$17,$31
	jr	$31
$L19:
	addiu	$3,$sp,32
	addiu	$4,$sp,16
	addu	$3,$3,$2
	addu	$4,$4,$2
	lbu	$3,0($3)
	lbu	$4,0($4)
	xor	$3,$4
	bnez	$3,$L17
	addiu	$2,1
	cmpi	$2,16
	btnez	$L19
	li	$2,257
	sh	$2,22($17)
	b	$L15
	.type	__pool_save_22, @object
__pool_save_22:
	.align	2
$L22:
	.word	-1090230299
$L23:
	.word	settings_key
$L24:
	.word	-1090230075
$L25:
	.word	-1090230311
	.type	__pend_save_22, @object
__pend_save_22:
	.end	save
	.size	save, .-save
	.section	.text.same,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	same
	.type	same, @function
same:
	.frame	$sp,0,$31		# vars= 0, regs= 0/0, args= 0, gp= 0
	.mask	0x00000000,0
	.fmask	0x00000000,0
	li	$2,0
	bnez	$4,$L28
	jr	$31
$L30:
	addiu	$4,1
	addiu	$5,1
$L28:
	lb	$3,0($4)
	lb	$2,0($5)
	xor	$2,$3
	beqz	$3,$L29
	beqz	$2,$L30
$L29:
	sltu	$2,1
	.set	noreorder
	.set	nomacro
	jr	$31
	move	$2,$24
	.set	macro
	.set	reorder

	.end	same
	.size	same, .-same
	.section	.rodata.supported.str1.4,"aMS",@progbits,1
	.align	2
$LC9:
	.ascii	"btmusic\000"
	.align	2
$LC10:
	.ascii	"linein\000"
	.align	2
$LC11:
	.ascii	"spdif_in\000"
	.align	2
$LC12:
	.ascii	"i2srx_in\000"
	.align	2
$LC13:
	.ascii	"nor_mplayer\000"
	.align	2
$LC14:
	.ascii	"uhost_mplayer\000"
	.align	2
$LC15:
	.ascii	"sd_mplayer\000"
	.section	.text.supported,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	supported
	.type	supported, @function
supported:
	.frame	$sp,24,$31		# vars= 0, regs= 1/0, args= 16, gp= 0
	.mask	0x80000000,-4
	.fmask	0x00000000,0
	lw	$2,$L38
	save	24,$31
	jalr	$2
	move	$4,$2
	lw	$5,$L39
	.set	noreorder
	.set	nomacro
	jal	same
	move	$6,$2
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L40
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L41
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L42
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L43
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L44
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

	bnez	$2,$L35
	lw	$5,$L45
	.set	noreorder
	.set	nomacro
	jal	same
	move	$4,$6
	.set	macro
	.set	reorder

$L35:
	restore	24,$31
	jr	$31
	.type	__pool_supported_38, @object
__pool_supported_38:
	.align	2
$L38:
	.word	-1090227847
$L39:
	.word	$LC9
$L40:
	.word	$LC10
$L41:
	.word	$LC11
$L42:
	.word	$LC12
$L43:
	.word	$LC13
$L44:
	.word	$LC14
$L45:
	.word	$LC15
	.type	__pend_supported_38, @object
__pend_supported_38:
	.end	supported
	.size	supported, .-supported
	.section	.text.context,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	context
	.type	context, @function
context:
	.frame	$sp,24,$31		# vars= 0, regs= 2/0, args= 16, gp= 0
	.mask	0x80010000,-4
	.fmask	0x00000000,0
	save	24,$16,$31
	.set	noreorder
	.set	nomacro
	jal	supported
	move	$16,$4
	.set	macro
	.set	reorder

	li	$3,0
	beqz	$2,$L47
	lw	$2,$L54
	jalr	$2
	move	$3,$2
$L47:
	lw	$2,$L55
	lw	$4,16($16)
	lbu	$2,0($2)
	cmp	$3,$4
	zeb	$2
	btnez	$L48
	lbu	$4,20($16)
	xor	$4,$2
	beqz	$4,$L46
$L48:
	sb	$2,20($16)
	lw	$2,4($16)
	sw	$3,16($16)
	addiu	$2,1
	sw	$2,4($16)
	li	$2,0
	sb	$2,23($16)
	li	$2,0
	sw	$2,8($16)
$L46:
	restore	24,$16,$31
	jr	$31
	.type	__pool_context_54, @object
__pool_context_54:
	.align	2
$L54:
	.word	-1090231827
$L55:
	.word	-1077782683
	.type	__pend_context_54, @object
__pend_context_54:
	.end	context
	.size	context, .-context
	.section	.text.apply,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	apply
	.type	apply, @function
apply:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	lw	$2,16($4)
	save	$4-$5,40,$16,$17,$31
	li	$17,0
	move	$16,$4
	sw	$17,16($sp)
	bnez	$2,$L57
$L59:
	.set	noreorder
	.set	nomacro
	jal	error
	move	$4,$16
	.set	macro
	.set	reorder

	li	$2,1
	neg	$2,$2
$L56:
	restore	40,$16,$17,$31
	jr	$31
$L57:
	lw	$2,$L71
	jalr	$2
	lw	$3,16($16)
	xor	$2,$3
	bnez	$2,$L59
	jal	supported
	beqz	$2,$L59
	lw	$4,72($16)
	bnez	$4,$L60
	lw	$2,$L72
	li	$4,14
	addiu	$6,$sp,16
	.set	noreorder
	.set	nomacro
	jalr	$2
	li	$5,0
	.set	macro
	.set	reorder

	move	$4,$2
	sw	$2,72($16)
	lw	$2,16($sp)
	slt	$2,512
	bteqz	$L61
	sw	$17,72($16)
	b	$L59
$L61:
	beqz	$4,$L59
$L60:
	addiu	$17,$16,7
	addiu	$17,69
	lw	$5,44($sp)
	.set	noreorder
	.set	nomacro
	jal	eq_make_block
	move	$6,$17
	.set	macro
	.set	reorder

	bnez	$2,$L59
	lw	$4,16($16)
	lw	$2,$L73
	li	$7,512
	move	$6,$17
	.set	noreorder
	.set	nomacro
	jalr	$2
	li	$5,12
	.set	macro
	.set	reorder

	bnez	$2,$L59
	lbu	$4,24($16)
	beqz	$4,$L56
	lw	$3,$L74
	li	$4,1
	sb	$2,24($16)
	sb	$4,0($3)
	lw	$3,$L75
	sb	$2,0($3)
	b	$L56
	.type	__pool_apply_71, @object
__pool_apply_71:
	.align	2
$L71:
	.word	-1090231827
$L72:
	.word	-1090231131
$L73:
	.word	-1090232883
$L74:
	.word	-1077782692
$L75:
	.word	-1077782694
	.type	__pend_apply_71, @object
__pend_apply_71:
	.end	apply
	.size	apply, .-apply
	.section	.text.load.part.0,"ax",@progbits
	.align	2
	.set	mips16
	.set	nomicromips
	.ent	load.part.0
	.type	load.part.0, @function
load.part.0:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	48,$16,$17,$31
	lw	$2,$L81
	li	$17,1
	move	$16,$4
	sb	$17,21($4)
	li	$6,16
	lw	$4,$L82
	.set	noreorder
	.set	nomacro
	jalr	$2
	addiu	$5,$sp,16
	.set	macro
	.set	reorder

	cmpi	$2,16
	btnez	$L76
	addiu	$5,$16,7
	addiu	$5,21
	.set	noreorder
	.set	nomacro
	jal	eq_settings_decode
	addiu	$4,$sp,16
	.set	macro
	.set	reorder

	bnez	$2,$L76
	sb	$17,22($16)
$L76:
	restore	48,$16,$17,$31
	jr	$31
	.type	__pool_load.part.0_81, @object
__pool_load.part.0_81:
	.align	2
$L81:
	.word	-1090230311
$L82:
	.word	settings_key
	.type	__pend_load.part.0_81, @object
__pend_load.part.0_81:
	.end	load.part.0
	.size	load.part.0, .-load.part.0
	.section	.text.eq_config_init,"ax",@progbits
	.align	2
	.globl	eq_config_init
	.set	mips16
	.set	nomicromips
	.ent	eq_config_init
	.type	eq_config_init, @function
eq_config_init:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	$4-$5,40,$16,$17,$31
	lw	$17,$L89
	cmpi	$6,76
	lw	$16,0($17)
	jal	runtime
	lw	$7,$L90
	bteqz	$L84
$L88:
	lw	$5,44($sp)
	.set	noreorder
	.set	nomacro
	jalr	$7
	lw	$4,40($sp)
	.set	macro
	.set	reorder

	move	$16,$2
$L83:
	move	$2,$16
	restore	40,$16,$17,$31
	jr	$31
$L84:
	bnez	$2,$L86
	lw	$2,$L91
	li	$4,664
	.set	noreorder
	.set	nomacro
	jalr	$2
	sw	$7,16($sp)
	.set	macro
	.set	reorder

	move	$16,$2
	lw	$7,16($sp)
	bnez	$2,$L86
	lw	$2,40($sp)
	li	$6,76
	sw	$2,0($17)
	b	$L88
$L86:
	move	$4,$16
	li	$6,664
	.set	noreorder
	.set	nomacro
	jalr	$7
	li	$5,0
	.set	macro
	.set	reorder

	lw	$2,$L92
	addiu	$5,$16,7
	addiu	$4,$16,7
	sw	$16,0($17)
	lw	$7,$L93
	sw	$2,76($16)
	lw	$6,$L94
	addiu	$5,69
	.set	noreorder
	.set	nomacro
	jal	eq_editor_init
	addiu	$4,97
	.set	macro
	.set	reorder

	b	$L83
	.type	__pool_eq_config_init_89, @object
__pool_eq_config_init_89:
	.align	2
$L89:
	.word	-1077780540
$L90:
	.word	-1090376755
$L91:
	.word	-1090375843
$L92:
	.word	1363490097
$L93:
	.word	save
$L94:
	.word	apply
	.type	__pend_eq_config_init_89, @object
__pend_eq_config_init_89:
	.end	eq_config_init
	.size	eq_config_init, .-eq_config_init
	.section	.text.eq_key_hook,"ax",@progbits
	.align	2
	.globl	eq_key_hook
	.set	mips16
	.set	nomicromips
	.ent	eq_key_hook
	.type	eq_key_hook, @function
eq_key_hook:
	.frame	$sp,48,$31		# vars= 8, regs= 3/0, args= 24, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	48,$16,$17,$31
	.set	noreorder
	.set	nomacro
	jal	runtime
	move	$16,$4
	.set	macro
	.set	reorder

	bnez	$2,$L96
	lw	$2,$L110
	xor	$2,$16
	bnez	$2,$L97
$L98:
	li	$2,0
$L95:
	restore	48,$16,$17,$31
	jr	$31
$L96:
	move	$17,$2
	lbu	$2,21($2)
	bnez	$2,$L99
	.set	noreorder
	.set	nomacro
	jal	load.part.0
	move	$4,$17
	.set	macro
	.set	reorder

$L99:
	.set	noreorder
	.set	nomacro
	jal	context
	move	$4,$17
	.set	macro
	.set	reorder

	lbu	$2,38($17)
	sw	$2,24($sp)
	lw	$2,$L111
	jalr	$2
	lw	$3,4($17)
	addiu	$5,$17,7
	addiu	$4,$17,7
	sw	$3,16($sp)
	move	$7,$2
	move	$6,$16
	addiu	$5,57
	.set	noreorder
	.set	nomacro
	jal	eq_remote_event
	addiu	$4,21
	.set	macro
	.set	reorder

	beqz	$2,$L97
	lw	$3,24($sp)
	beqz	$3,$L100
	lbu	$4,38($17)
	bnez	$4,$L100
	lw	$5,$L112
	li	$6,1
	sb	$6,0($5)
	lw	$5,$L113
	sb	$4,0($5)
$L100:
	slt	$2,0
	bteqz	$L98
	.set	noreorder
	.set	nomacro
	jal	error
	move	$4,$17
	.set	macro
	.set	reorder

	b	$L98
$L97:
	lw	$2,$L114
	.set	noreorder
	.set	nomacro
	jalr	$2
	move	$4,$16
	.set	macro
	.set	reorder

	b	$L95
	.type	__pool_eq_key_hook_110, @object
__pool_eq_key_hook_110:
	.align	2
$L110:
	.word	2097233
$L111:
	.word	-1089979031
$L112:
	.word	-1077782692
$L113:
	.word	-1077782694
$L114:
	.word	-1090237587
	.type	__pend_eq_key_hook_110, @object
__pend_eq_key_hook_110:
	.end	eq_key_hook
	.size	eq_key_hook, .-eq_key_hook
	.section	.text.eq_timer_hook,"ax",@progbits
	.align	2
	.globl	eq_timer_hook
	.set	mips16
	.set	nomicromips
	.ent	eq_timer_hook
	.type	eq_timer_hook, @function
eq_timer_hook:
	.frame	$sp,48,$31		# vars= 16, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	save	$4,48,$16,$17,$31
	jal	runtime
	move	$17,$2
	lw	$2,$L151
	jalr	$2
	move	$16,$2
	beqz	$17,$L117
	lbu	$2,21($17)
	bnez	$2,$L118
	.set	noreorder
	.set	nomacro
	jal	load.part.0
	move	$4,$17
	.set	macro
	.set	reorder

$L118:
	.set	noreorder
	.set	nomacro
	jal	context
	move	$4,$17
	.set	macro
	.set	reorder

	lbu	$2,38($17)
	lw	$7,4($17)
	addiu	$4,$17,7
	move	$6,$16
	li	$5,7
	addiu	$4,21
	.set	noreorder
	.set	nomacro
	jal	eq_editor_event
	sw	$2,24($sp)
	.set	macro
	.set	reorder

	slt	$2,0
	bteqz	$L119
	.set	noreorder
	.set	nomacro
	jal	error
	move	$4,$17
	.set	macro
	.set	reorder

$L119:
	lw	$2,24($sp)
	beqz	$2,$L120
	lbu	$2,38($17)
	bnez	$2,$L120
	lw	$2,16($17)
	bnez	$2,$L121
$L120:
	lbu	$2,24($17)
	beqz	$2,$L122
	lw	$2,12($17)
	subu	$2,$16,$2
	sltu	$2,1000
	btnez	$L122
$L121:
	lw	$2,$L152
	li	$4,1
	sb	$4,0($2)
	lw	$4,$L153
	li	$2,0
	sb	$2,0($4)
	sb	$2,24($17)
$L122:
	lbu	$2,38($17)
	beqz	$2,$L117
	lw	$2,$L154
	li	$4,0
	sh	$4,0($2)
	lw	$2,$L155
	li	$4,1
	sb	$4,0($2)
$L117:
	lw	$2,$L156
	.set	noreorder
	.set	nomacro
	jalr	$2
	lw	$4,48($sp)
	.set	macro
	.set	reorder

	beqz	$17,$L115
	lbu	$2,22($17)
	beqz	$2,$L126
	lbu	$2,23($17)
	bnez	$2,$L126
	lw	$2,16($17)
	beqz	$2,$L126
	lbu	$2,38($17)
	bnez	$2,$L126
	lw	$2,8($17)
	subu	$2,$16,$2
	sltu	$2,1000
	btnez	$L126
	addiu	$5,$17,7
	sw	$16,8($17)
	addiu	$5,21
	.set	noreorder
	.set	nomacro
	jal	apply
	move	$4,$17
	.set	macro
	.set	reorder

	bnez	$2,$L126
	li	$2,1
	sb	$2,23($17)
$L126:
	lbu	$2,24($17)
	beqz	$2,$L128
	lw	$2,12($17)
	subu	$2,$16,$2
	sltu	$2,1000
	bteqz	$L128
	lw	$2,16($17)
	beqz	$2,$L128
	lw	$16,$L157
	li	$6,1
	li	$5,14
	.set	noreorder
	.set	nomacro
	jalr	$16
	li	$4,0
	.set	macro
	.set	reorder

	li	$6,1
	li	$5,27
	.set	noreorder
	.set	nomacro
	jalr	$16
	li	$4,1
	.set	macro
	.set	reorder

	li	$6,1
	li	$5,27
	.set	noreorder
	.set	nomacro
	jalr	$16
	li	$4,2
	.set	macro
	.set	reorder

	li	$6,0
	li	$5,0
	.set	noreorder
	.set	nomacro
	jalr	$16
	li	$4,3
	.set	macro
	.set	reorder

$L115:
	restore	48,$16,$17,$31
	jr	$31
$L128:
	addiu	$4,$17,7
	addiu	$7,$sp,16
	addiu	$6,$sp,20
	move	$5,$16
	.set	noreorder
	.set	nomacro
	jal	eq_display_frame
	addiu	$4,21
	.set	macro
	.set	reorder

	slt	$2,1
	btnez	$L115
	li	$16,0
$L131:
	addiu	$2,$sp,16
	addu	$3,$2,$16
	addiu	$2,$sp,20
	addu	$2,$2,$16
	lbu	$5,0($2)
	lbu	$6,0($3)
	lw	$2,$L157
	move	$4,$16
	.set	noreorder
	.set	nomacro
	jalr	$2
	addiu	$16,1
	.set	macro
	.set	reorder

	cmpi	$16,4
	btnez	$L131
	b	$L115
	.type	__pool_eq_timer_hook_151, @object
__pool_eq_timer_hook_151:
	.align	2
$L151:
	.word	-1089979031
$L152:
	.word	-1077782692
$L153:
	.word	-1077782694
$L154:
	.word	-1077782736
$L155:
	.word	-1077782734
$L156:
	.word	-1090224039
$L157:
	.word	-1090198155
	.type	__pend_eq_timer_hook_151, @object
__pend_eq_timer_hook_151:
	.end	eq_timer_hook
	.size	eq_timer_hook, .-eq_timer_hook
	.section	.rodata.settings_key,"a"
	.align	2
	.type	settings_key, @object
	.size	settings_key, 10
settings_key:
	.ascii	"USER_PEQ5\000"
	.ident	"GCC: (Debian 14.2.0-13) 14.2.0"
	.section	.note.GNU-stack,"",@progbits

/* Preserve every register except v0/v1/t8, as the original getter does. */
.section .text.eq_channel_get,"ax",@progbits
.align 2
.globl eq_channel_get
.set mips16
.set nomicromips
.ent eq_channel_get
.type eq_channel_get,@function
eq_channel_get:
 lw $2,eq_channel_root
 lw $3,0($2)
 addu $3,$3,$4
 addiu $3,64
 lbu $2,0($3)
 sltu $2,17
 btnez eq_channel_low
 li $2,16
eq_channel_return:
 .set noreorder
 jr $31
 sb $2,0($3)
 .set reorder
eq_channel_low:
 sltu $2,6
 bteqz eq_channel_return
 li $2,6
 b eq_channel_return
.align 2
eq_channel_root:
 .word 0xbfc25fc4
.end eq_channel_get
.size eq_channel_get,.-eq_channel_get

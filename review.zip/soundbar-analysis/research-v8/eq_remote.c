#include "eq_remote.h"
int eq_remote_event(eq_editor *e,eq_remote_state *r,uint32_t raw,uint32_t now,uint32_t generation) {
 int rc;unsigned key=raw&0xffffU;uint32_t type=raw&0xffff0000UL;
 if(e->editing&&generation!=e->player_generation)(void)eq_editor_event(e,EQ_TICK,now,generation);
 if(key==EQ_KEY_CODE){
  if(type==KEY_SHORT_DOWN){r->eq_held=0;r->released=0;return e->editing?1:0;}
  if(type==KEY_LONG){
   if(!r->eq_held){r->eq_held=1;r->released=0;rc=eq_editor_event(e,EQ_OPEN,now,generation);if(rc<0)return -1;}
   return 1;
  }
  if(type==KEY_LONG_UP||type==KEY_HOLD_UP){
   if(r->eq_held){r->eq_held=0;r->released=1;r->released_at=now;return 1;}
   return e->editing?1:0;
  }
  if(type==KEY_SHORT_UP){
   if(r->eq_held){r->eq_held=0;r->released=1;r->released_at=now;return 1;}
   if(r->released&&(uint32_t)(now-r->released_at)<100U)return 1;
   r->released=0;
   if(e->editing){rc=eq_editor_event(e,EQ_SAVE_EXIT,now,generation);return rc<0?-1:1;}
  }
  if(r->eq_held)return 1;
  return 0;
 }
 if(!e->editing)return 0;
 if(key==GEAR_KEY_CODE&&type==KEY_SHORT_UP){(void)eq_editor_event(e,EQ_NEXT_BAND,now,generation);return 1;}
 if((key==PLUS_KEY_CODE||key==MINUS_KEY_CODE)&&(type==KEY_SHORT_UP||type==KEY_LONG||type==KEY_HOLD)){
  rc=eq_editor_event(e,key==PLUS_KEY_CODE?EQ_GAIN_UP:EQ_GAIN_DOWN,now,generation);return rc<0?-1:1;
 }
 return 0;
}

/* Exact TSBB04B ABI adapter; never run on a host or another firmware. */
#include "eq_remote.h"
#ifdef EQ_TARGET_TEST
#include "eq_target_test_api.h"
#else
#define target_alloc ((void *(*)(unsigned))0xbf022f5dUL)
#define target_memset ((void *(*)(void *,int,unsigned))0xbf022bcdUL)
#define target_player ((void *(*)(void))0xbf0461edUL)
#define target_app ((const char *(*)(void))0xbf047179UL)
#define target_param ((int (*)(void *,int,const void *,unsigned))0xbf045dcdUL)
#define target_effect ((const uint8_t *(*)(unsigned,unsigned,int *))0xbf0464a5UL)
#define target_get ((int (*)(const char *,void *,unsigned))0xbf0467d9UL)
#define target_set ((int (*)(const char *,const void *,unsigned))0xbf0467e5UL)
#define target_flush ((int (*)(const char *))0xbf0468c5UL)
#define target_draw ((void (*)(unsigned,unsigned,unsigned))0xbf04e575UL)
#define target_uptime ((uint32_t (*)(void))0xbf083d69UL)
#define target_dispatch ((int (*)(uint32_t))0xbf044b6dUL)
#define target_timer ((void (*)(void *))0xbf048059UL)
#define ROOT_POINTER (*(uint8_t * volatile *)0xbfc25fc4UL)
#define STATIC_CONFIG ((uint8_t *)0xbfc25f78UL)
#define CURRENT_MODE (*(volatile uint8_t *)0xbfc25765UL)
#define DISPLAY_COUNT (*(volatile uint16_t *)0xbfc25730UL)
#define UI_DIRTY (*(volatile uint8_t *)0xbfc2575cUL)
#define UI_AGE (*(volatile uint8_t *)0xbfc2575aUL)
#define DISPLAY_STATE (*(volatile uint8_t *)0xbfc25732UL)
#endif
#define CONFIG_BYTES 76U
#define STATE_OFFSET ((CONFIG_BYTES+sizeof(void*)-1U)&~(sizeof(void*)-1U))
#define EQ_MAGIC 0x51453531UL
static const char settings_key[]="USER_PEQ5";
typedef struct {
 uint32_t magic,generation,last_attempt,error_at;
 void *player;uint8_t mode,loaded,configured,applied,error;
 eq_editor editor;eq_remote_state remote;
 const uint8_t *factory;uint8_t block[EQ_BLOCK_SIZE];
} eq_runtime;
static eq_runtime *runtime(void) {
 uint8_t *base=ROOT_POINTER;eq_runtime *t;
 if(!base||base==STATIC_CONFIG)return 0;
 t=(eq_runtime *)(base+STATE_OFFSET);return t->magic==EQ_MAGIC?t:0;
}
static int same(const char *a,const char *b){if(!a)return 0;while(*a&&*a==*b){a++;b++;}return *a==*b;}
static int supported(void){const char *s=target_app();return same(s,"btmusic")||same(s,"linein")||same(s,"spdif_in")||same(s,"i2srx_in")||same(s,"nor_mplayer")||same(s,"uhost_mplayer")||same(s,"sd_mplayer");}
static void error(eq_runtime *t){t->error=1;t->error_at=target_uptime();}
static void context(eq_runtime *t){
 void *p=supported()?target_player():0;uint8_t mode=CURRENT_MODE;
 if(p!=t->player||mode!=t->mode){t->player=p;t->mode=mode;t->generation++;t->applied=0;t->last_attempt=0;}
}
static int apply(void *opaque,const int8_t gains[EQ_BANDS]){
 eq_runtime *t=(eq_runtime *)opaque;int size=0;
 if(!t->player||target_player()!=t->player||!supported()){error(t);return -1;}
 if(!t->factory){t->factory=target_effect(14,0,&size);if(size<EQ_BLOCK_SIZE)t->factory=0;}
 if(!t->factory||eq_make_block(t->factory,gains,t->block)||target_param(t->player,12,t->block,EQ_BLOCK_SIZE)){error(t);return -1;}
 if(t->error){t->error=0;UI_DIRTY=1;UI_AGE=0;}return 0;
}
static int save(void *opaque,const int8_t gains[EQ_BANDS]){
 eq_runtime *t=(eq_runtime *)opaque;uint8_t blob[EQ_SETTINGS_SIZE],check[EQ_SETTINGS_SIZE];unsigned i;
 if(eq_settings_encode(gains,blob)||target_set(settings_key,blob,EQ_SETTINGS_SIZE)<0||target_flush(settings_key)<0||target_get(settings_key,check,EQ_SETTINGS_SIZE)!=EQ_SETTINGS_SIZE){error(t);return -1;}
 for(i=0;i<EQ_SETTINGS_SIZE;i++)if(blob[i]!=check[i]){error(t);return -1;}
 t->configured=1;t->applied=1;return 0;
}
static void load(eq_runtime *t){
 uint8_t blob[EQ_SETTINGS_SIZE];
 if(t->loaded)return;
 t->loaded=1;
 if(target_get(settings_key,blob,EQ_SETTINGS_SIZE)==EQ_SETTINGS_SIZE&&!eq_settings_decode(blob,t->editor.saved))t->configured=1;
}
void *eq_config_init(void *original,int fill,unsigned bytes){
 uint8_t *base=ROOT_POINTER;eq_runtime *t=runtime();
 if(bytes!=CONFIG_BYTES)return target_memset(original,fill,bytes);
 if(!t){base=(uint8_t *)target_alloc(STATE_OFFSET+sizeof(eq_runtime));if(!base){ROOT_POINTER=(uint8_t *)original;return target_memset(original,fill,bytes);}}
 target_memset(base,0,STATE_OFFSET+sizeof(eq_runtime));ROOT_POINTER=base;
 t=(eq_runtime *)(base+STATE_OFFSET);t->magic=EQ_MAGIC;eq_editor_init(&t->editor,t,apply,save);return base;
}
int eq_key_hook(uint32_t raw){
 eq_runtime *t=runtime();int handled;uint8_t was;
 if(!t&&(raw&0xffffU)==EQ_KEY_CODE&&(raw&0xffff0000UL)==KEY_LONG)return 0;
 if(t){load(t);context(t);was=t->editor.editing;handled=eq_remote_event(&t->editor,&t->remote,raw,target_uptime(),t->generation);if(handled){if(was&&!t->editor.editing){UI_DIRTY=1;UI_AGE=0;}if(handled<0)error(t);return 0;}}
 return target_dispatch(raw);
}
void eq_timer_hook(void *timer){
 eq_runtime *t=runtime();uint8_t was;uint32_t now=target_uptime();unsigned i;uint8_t glyph[4],enabled[4];
 if(t){
  load(t);context(t);was=t->editor.editing;if(eq_editor_event(&t->editor,EQ_TICK,now,t->generation)<0)error(t);
  if((was&&!t->editor.editing&&t->player)||(t->error&&(uint32_t)(now-t->error_at)>=1000U)){UI_DIRTY=1;UI_AGE=0;t->error=0;}
  if(t->editor.editing){DISPLAY_COUNT=0;DISPLAY_STATE=1;}
 }
 target_timer(timer);
 if(!t)return;
 if(t->configured&&!t->applied&&t->player&&!t->editor.editing&&(uint32_t)(now-t->last_attempt)>=1000U){t->last_attempt=now;if(!apply(t,t->editor.saved))t->applied=1;}
 if(t->error&&(uint32_t)(now-t->error_at)<1000U&&t->player){target_draw(0,14,1);target_draw(1,27,1);target_draw(2,27,1);target_draw(3,0,0);}
 else if(eq_display_frame(&t->editor,now,glyph,enabled)>0)for(i=0;i<4;i++)target_draw(i,glyph[i],enabled[i]);
}

/* Tail-called by only the SW/SURR getter cases. Keep the v4 neutral index 11.
 * Clamp on every read, including the first startup restore, before a wire
 * command can be formed. No NVS migration or shifted channel levels. */
#ifdef EQ_TARGET_TEST
unsigned eq_channel_get(unsigned key) {
 uint8_t *base=ROOT_POINTER;unsigned value=base[64U+key];
 if(value<6U)value=6U;else if(value>16U)value=16U;
 base[64U+key]=(uint8_t)value;return value;
}

#endif

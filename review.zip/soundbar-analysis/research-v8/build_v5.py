"""Source-locked EQ remote candidate. Builds an OTA; never writes a device."""
from pathlib import Path
import struct,subprocess,os,json,hashlib,zlib,importlib.util
D=Path(__file__).resolve().parent;R=D.parent;BASE=0xbf000000
sp=importlib.util.spec_from_file_location('builder3',R/'research-v3/build_v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
env=dict(os.environ,LD_LIBRARY_PATH=str(R/'binutils/usr/lib/x86_64-linux-gnu'));binpath=R/'binutils/usr/bin'
def elf(path):
 b=Path(path).read_bytes();assert b[:6]==b'\x7fELF\x01\x01';off=struct.unpack_from('<I',b,32)[0];n,stridx=struct.unpack_from('<HH',b,48);size=struct.unpack_from('<H',b,46)[0];raw=[struct.unpack_from('<10I',b,off+size*i) for i in range(n)];strings=b[raw[stridx][4]:raw[stridx][4]+raw[stridx][5]];out=[]
 for x in raw:
  name=strings[x[0]:].split(b'\0')[0].decode();out.append(dict(name=name,type=x[1],flags=x[2],addr=x[3],off=x[4],size=x[5],link=x[6],align=x[8],entsize=x[9],data=b[x[4]:x[4]+x[5]]))
 return b,out
source=R/'candidates/v4-allranges-experimental/candidate-v4-allranges-experimental.bin';original=source.read_bytes();assert hashlib.sha256(original).hexdigest()=='50ce9ed4b65524c6238dc41af9c77000d1e3644f1a0345bdea709cae1c5b94d8'
parts=m.verify(original);entry,offset,length,_,oldcrc=parts['zephyr.bin'];plain=m.codec(original[offset:offset+length]);assert plain==(R/'candidates/v4-allranges-experimental/zephyr-decoded.bin').read_bytes()
pools=[dict(name=n,start=a,end=z) for n,a,z in [('key_diagnostics',0xa8f44,0xa93b0),('aset_diagnostics',0xaa6d8,0xaa818),('input_diagnostics',0xab9ec,0xabb58),('dae_diagnostics',0xc5a20,0xc5b48),('priority_assert',0xbf9e0,0xbf9e0+151),('idle_assert',0xc7ea4,0xc7ea4+139),('ota_mapping_log',0xbfe8c,0xbfe8c+109),('sinfo_assert',0xbe430,0xbe430+108),('sinfo_assert2',0xbe344,0xbe344+108),('info_assert',0xbe2dc,0xbe2dc+104),('priority_assert2',0xc78c8,0xc78c8+98)]]
for p in pools:
 assert p['start']%4==0
 b=plain[p['start']:p['end']];assert b[-1]==0 and all(c in [0,9,10,13] or 32<=c<127 for c in b),p
 p['next']=p['start']
def containing(address):return next((p for p in pools if BASE+p['start']<=address<BASE+p['end']),None)
# Refuse using a text pool with MIPS32-constructed incoming pointers. Literal
# pointer redirection below is valid only for the inspected source image.
for o in range(0,0xa8000-40,4):
 w=struct.unpack_from('<I',plain,o)[0]
 if w>>26!=15:continue
 reg=(w>>16)&31;hi=(w&65535)<<16
 if not 0xbf090000<=hi<=0xbf0e0000:continue
 for j in range(o+4,o+40,4):
  q=struct.unpack_from('<I',plain,j)[0];op=q>>26
  if ((q>>21)&31)!=reg or op not in [9,13]:continue
  lo=q&65535;addr=hi+((lo^0x8000)-0x8000) if op==9 else hi|lo
  assert not containing(addr),('unsupported constructed string pointer',hex(o),hex(j),hex(addr))
sections=[]
for name in ['eq_core','eq_remote','eq_target']:
 path=D/(name+'.o');_,ss=elf(path)
 for s in ss:
  if not (s['flags']&2) or not s['size']:continue
  if s['name'].startswith(('.text.','.rodata.','.rodata')):sections.append(dict(s,object=path))
  else:assert s['name'] in ['.reginfo','.MIPS.abiflags'],s['name']
for s in sections:
 s['reserve']=s['size']+(4 if s['name'].startswith('.rodata') else 0)
for s in sorted(sections,key=lambda s:s['reserve'],reverse=True):
 choices=[]
 for p in pools:
  align=max(4,s['align']);a=(p['next']+align-1)//align*align
  if a+s['reserve']<=p['end']:choices.append((p['end']-a-s['reserve'],p['start'],a,p))
 if not choices:raise RuntimeError('No verified text pool fits '+s['name']+' ('+str(s['size'])+' bytes)')
 _,_,a,p=min(choices,key=lambda x:x[:2]);s['dest']=a;s['pool']=p['name'];p['next']=a+s['reserve']
# This pool also contains the service identifier 'tool', which is semantic,
# not a log format. Retain its bytes and redirect its original references.
semantic_source=0xaa730
assert plain[semantic_source:semantic_source+5]==b'tool\0'
semantic_pool=next(p for p in pools if (p['next']+3)//4*4+8<=p['end'])
semantic_dest=(semantic_pool['next']+3)//4*4
semantic_pool['next']=semantic_dest+8
script=['SECTIONS {']
for i,s in enumerate(sections):script.append(f'.patch{i} 0x{BASE+s["dest"]:x} : {{ KEEP({s["object"]}({s["name"]})) }}')
script.append('/DISCARD/ : { *(.reginfo) *(.MIPS.abiflags) *(.pdr) *(.mdebug*) *(.comment) *(.note*) *(.gnu.attributes) }\n}')
(D/'eq_layout.ld').write_text('\n'.join(script))
subprocess.run([str(binpath/'mipsel-linux-gnu-ld'),'-EL','-T',str(D/'eq_layout.ld'),'-Map',str(D/'eq_layout.map'),'-o',str(D/'eq_linked.elf'),*[str(D/(n+'.o')) for n in ['eq_core','eq_remote','eq_target']]],env=env,check=True)
_,linked=elf(D/'eq_linked.elf');sym={}
for s in linked:
 if s['type']==2:
  strings=linked[s['link']]['data']
  for o in range(0,s['size'],s['entsize']):
   no,value,size,info,other,idx=struct.unpack_from('<IIIBBH',s['data'],o);name=strings[no:].split(b'\0')[0].decode()
   if idx and name:sym[name]=dict(address=value,size=size,other=other)
undefined=subprocess.check_output([str(binpath/'mipsel-linux-gnu-nm'),'-u',str(D/'eq_linked.elf')],env=env,text=True);assert not undefined.strip(),undefined
patched=bytearray(plain);edits=[]
def edit(at,before,after,purpose):
 if isinstance(before,str):before=bytes.fromhex(before)
 if isinstance(after,str):after=bytes.fromhex(after)
 assert len(before)==len(after) and patched[at:at+len(before)]==before,(hex(at),purpose)
 patched[at:at+len(before)]=after;edits.append(dict(offset=hex(at),length=len(before),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),purpose=purpose))
empty=0xbf0a8883;assert plain[empty-BASE]==0
pointer_changes=[]
for o in range(0,len(plain)-3,4):
 v=struct.unpack_from('<I',plain,o)[0]
 if containing(v):
  assert not containing(BASE+o)
  new=BASE+semantic_dest+(v-BASE-semantic_source) if BASE+semantic_source<=v<BASE+semantic_source+5 else empty
  edit(o,struct.pack('<I',v),struct.pack('<I',new),'preserve service identifier' if new!=empty else 'redirect reclaimed diagnostic text to empty format');pointer_changes.append(dict(offset=hex(o),old=hex(v),new=hex(new)))
for p in pools:edit(p['start'],plain[p['start']:p['end']],b'\0'*(p['end']-p['start']),'reclaim '+p['name'])
for s in linked:
 if s['flags']&2 and s['size']:
  assert s['name'].startswith('.patch'),s['name']
  at=s['addr']-BASE;p=containing(s['addr']);assert p and at+s['size']<=p['end']
  sections[int(s['name'][6:])]['linked_size']=s['size']
  edit(at,b'\0'*s['size'],s['data'],'install '+sections[int(s['name'][6:])]['name'])
edit(semantic_dest,b'\0'*5,b'tool\0','retain semantic service identifier')
def function(name):
 v=sym[name];assert v['other']&0xf0==0xf0,(name,v);assert not(v['address']&2),(name,v);return v['address']&~1
edit(0x17ac6,m.jal(0xbf044b6c),m.jal(function('eq_key_hook')),'route raw keys through scoped EQ handler; retain original delay slot')
assert plain[0x17aca:0x17acc]==bytes.fromhex('9167')
edit(0x3d276,m.jal(0xbf022bcc),m.jal(function('eq_config_init')),'initialize extended configuration sidecar with allocation fallback')
edit(0x3d27a,'80d8','0065','sidecar initializer owns global pointer assignment')
edit(0x493c8,struct.pack('<I',0xbf048059),struct.pack('<I',function('eq_timer_hook')|1),'retain original timer then render EQ overlay')
edit(0x49180,'325a','1e5a','display dim after 30 ticks')
edit(0x491e6,'325b0065','465b0065','display off after additional 70 ticks')
# The original statically allocated config is addressed only by the init literal.
config_refs=[o for o in range(0,len(plain)-3,4) if 0xbfc25f78<=struct.unpack_from('<I',plain,o)[0]<0xbfc25fc4];assert config_refs==[0x3d3dc]
# Both getter cases tail-jump without modifying the original return address.
# PC-relative lw v0,+8; jrc v0; nop; compressed-code function pointer.
for at in [0x3d0c2,0x3d0d6]:
 edit(at,plain[at:at+10],bytes.fromhex('02b280ea0065')+struct.pack('<I',function('eq_channel_get')|1),'clamp SW/SURR saved index to 6..16 on every read')
for at,old,new in [(0x4e02e,'165b','115b'),(0x4e032,'1568','1068'),(0x4e090,'0168','0668'),(0x4e094,'025a','075a'),(0x4e128,'165a','115a'),(0x4e12c,'1568','1068'),(0x4e1a2,'0168','0668'),(0x4e1a6,'025a','075a')]:
 edit(at,old,new,'bound SW/SURR buttons to stored 6..16, displayed -5..+5')
assert patched[0xa8b98:0xa8f44]==plain[0xa8b98:0xa8f44]
assert patched[0x51264:0x512f6]==plain[0x51264:0x512f6]
assert patched[0xc69ac:0xc6a28]==plain[0xc69ac:0xc6a28]
assert patched[0x4e0a8:0x4e110]==plain[0x4e0a8:0x4e110] and patched[0x4ee44:0x4ee84]==plain[0x4ee44:0x4ee84]
encoded=m.codec(bytes(patched),True);assert len(encoded)==length and m.codec(encoded)==patched
out=bytearray(original);out[offset:offset+length]=encoded;crc=zlib.crc32(encoded);struct.pack_into('<I',out,entry+28,crc)
xe,xo,xn,_,_=parts['ota.xml'];xml=bytes(out[xo:xo+xn]);old=f'0x{oldcrc:08x}'.encode();assert xml.count(old)==1;xml=xml.replace(old,f'0x{crc:08x}'.encode());out[xo:xo+xn]=xml;struct.pack_into('<I',out,xe+28,zlib.crc32(xml));struct.pack_into('<I',out,24,zlib.crc32(out[1024:]));struct.pack_into('<I',out,4,zlib.crc32(out[8:1024]));m.verify(out)
for name in ['mbrec.bin','param.bin','sdfs.bin']:
 _,o,n,_,_=parts[name];assert out[o:o+n]==original[o:o+n]
folder=R/'candidates/v5.1-eq-channel-limits';folder.mkdir(exist_ok=True,parents=True);(folder/'ota.bin').write_bytes(out);(folder/'zephyr-decoded.bin').write_bytes(patched)
report=dict(profile='v5.1-eq-channel-limits',source_v4_sha256=hashlib.sha256(original).hexdigest(),candidate_sha256=hashlib.sha256(out).hexdigest(),candidate_bytes=len(out),hardware_tested=False,channel_ui_ranges={'SW':[-5,5],'CEN':[-10,10],'SURR':[-5,5]},channel_storage_indices=[6,16],channel_neutral_index=11,saved_values_clamped_on_read=True,cec_dispatch_unchanged=True,arc_guard_unchanged=True,center_unchanged=True,keymap_unchanged=True,display_ticks=[30,70],preserved_service_string_address=hex(BASE+semantic_dest),reclaimed_pools=pools,sections=[dict(object=s['object'].name,name=s['name'],size=s['linked_size'],address=hex(BASE+s['dest']),pool=s['pool']) for s in sections],symbols=sym,redirected_diagnostic_pointers=pointer_changes,edits=edits,crc_and_xml_verified=True,partition_sizes_unchanged=True)
(folder/'verification.json').write_text(json.dumps(report,indent=2)+'\n');(D/'firmware-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(report['candidate_sha256'],len(out))

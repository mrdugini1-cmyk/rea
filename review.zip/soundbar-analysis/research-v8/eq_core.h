#ifndef TUVIO_EQ_CORE_H
#define TUVIO_EQ_CORE_H
#ifdef EQ_FREESTANDING
typedef __UINT8_TYPE__ uint8_t;
typedef __INT8_TYPE__ int8_t;
typedef __UINT16_TYPE__ uint16_t;
typedef __INT16_TYPE__ int16_t;
typedef __UINT32_TYPE__ uint32_t;
#else
#include <stdint.h>
#endif
#define EQ_BANDS 5
#define EQ_BLOCK_SIZE 512
#define EQ_SETTINGS_SIZE 16
#define EQ_GAIN_MIN (-6)
#define EQ_GAIN_MAX 6
/* Gain units exposed to the UI: 1 dB. Serialized DSP fields: 0.1 dB. */
extern const uint16_t eq_frequencies[EQ_BANDS];
int eq_make_block(const uint8_t factory[EQ_BLOCK_SIZE], const int8_t gain[EQ_BANDS], uint8_t output[EQ_BLOCK_SIZE]);
int eq_settings_encode(const int8_t gain[EQ_BANDS], uint8_t output[EQ_SETTINGS_SIZE]);
int eq_settings_decode(const uint8_t input[EQ_SETTINGS_SIZE], int8_t gain[EQ_BANDS]);
typedef int (*eq_apply_fn)(void *, const int8_t[EQ_BANDS]);
typedef int (*eq_save_fn)(void *, const int8_t[EQ_BANDS]);
typedef struct {
 int8_t saved[EQ_BANDS], draft[EQ_BANDS];
 uint8_t editing, band, gain_first;
 uint32_t last_action_ms, player_generation;
 void *opaque; eq_apply_fn apply; eq_save_fn save;
} eq_editor;
enum eq_action { EQ_OPEN, EQ_PREVIOUS_BAND, EQ_NEXT_BAND, EQ_GAIN_UP, EQ_GAIN_DOWN,
 EQ_SAVE_EXIT, EQ_CANCEL, EQ_TICK, EQ_POWER_OR_SOURCE };
int eq_display_frame(const eq_editor *, uint32_t now_ms, uint8_t glyph[4], uint8_t enabled[4]);
void eq_editor_init(eq_editor *, void *, eq_apply_fn, eq_save_fn);
/* Returns 1 if consumed, 0 for the original handler, -1 on an apply/save error.
 * Context changes never apply an old draft to a new player. Power/source events
 * remain unconsumed after cancellation, allowing normal ARC/CEC handling. */
int eq_editor_event(eq_editor *, enum eq_action, uint32_t now_ms, uint32_t player_generation);
#endif

	.file	1 "eq_remote.c"
	.section .mdebug.abi32
	.previous
	.nan	legacy
	.module	softfloat
	.module	oddspreg
	.module	arch=mips32
	.text
	.section	.text.eq_remote_event,"ax",@progbits
	.align	2
	.globl	eq_remote_event
	.set	mips16
	.set	nomicromips
	.ent	eq_remote_event
	.type	eq_remote_event, @function
eq_remote_event:
	.frame	$sp,40,$31		# vars= 8, regs= 3/0, args= 16, gp= 0
	.mask	0x80030000,-4
	.fmask	0x00000000,0
	lw	$2,$L42
	save	40,$16,$17,$31
	move	$16,$6
	move	$17,$16
	and	$16,$2
	lbu	$2,10($4)
	zeh	$17
	move	$6,$7
	move	$3,$5
	lw	$7,56($sp)
	cmpi	$17,81
	beqz	$2,$L2
	lw	$2,20($4)
	xor	$2,$7
	beqz	$2,$L3
	move	$2,$24
	sw	$5,44($sp)
	li	$5,7
	sw	$6,52($sp)
	sw	$4,40($sp)
	.set	noreorder
	.set	nomacro
	jal	eq_editor_event
	sw	$2,16($sp)
	.set	macro
	.set	reorder

	lw	$2,16($sp)
	lw	$4,40($sp)
	move	$24,$2
	lw	$6,52($sp)
	lw	$7,56($sp)
	lw	$3,44($sp)
	btnez	$L4
$L22:
	lw	$2,$L43
	xor	$2,$16
	bnez	$2,$L5
	sh	$2,0($3)
$L12:
	lbu	$2,10($4)
$L13:
	neg	$2,$2
	srl	$2,$2,31
	b	$L1
$L5:
	lw	$5,$L44
	lbu	$2,0($3)
	xor	$5,$16
	bnez	$5,$L7
	bnez	$2,$L9
	li	$2,1
	sh	$2,0($3)
$L40:
	jal	eq_editor_event
	slt	$2,0
	bteqz	$L9
	li	$2,1
	neg	$2,$2
$L1:
	restore	40,$16,$17,$31
	jr	$31
$L7:
	lw	$5,$L45
	lw	$17,$L46
	addu	$5,$16,$5
	and	$5,$17
	bnez	$5,$L11
	beqz	$2,$L12
$L14:
	li	$2,256
	sh	$2,0($3)
	sw	$6,4($3)
$L9:
	li	$2,1
	b	$L1
$L11:
	lw	$5,$L47
	xor	$5,$16
	bnez	$5,$L13
	bnez	$2,$L14
	lbu	$5,1($3)
	beqz	$5,$L15
	lw	$5,4($3)
	subu	$5,$6,$5
	sltu	$5,100
	btnez	$L9
$L15:
	li	$5,0
	sb	$5,1($3)
	lbu	$3,10($4)
	li	$5,5
	beqz	$3,$L13
	b	$L40
$L4:
	lbu	$2,10($4)
	bnez	$2,$L17
$L19:
	li	$2,0
	b	$L1
$L18:
	addiu	$2,$17,-8
	addiu	$2,-71
	sltu	$2,2
	bteqz	$L19
	lw	$2,$L48
	lw	$3,$L49
	addu	$2,$16,$2
	and	$2,$3
	beqz	$2,$L20
	lw	$2,$L44
	xor	$2,$16
	bnez	$2,$L19
$L20:
	cmpi	$17,79
	li	$5,4
	btnez	$L40
	li	$5,3
	b	$L40
$L2:
	bteqz	$L22
	b	$L19
$L3:
	bteqz	$L22
$L17:
	cmpi	$17,78
	btnez	$L18
	lw	$2,$L47
	xor	$2,$16
	bnez	$2,$L19
	.set	noreorder
	.set	nomacro
	jal	eq_editor_event
	li	$5,2
	.set	macro
	.set	reorder

	b	$L9
	.type	__pool_eq_remote_event_42, @object
__pool_eq_remote_event_42:
	.align	2
$L42:
	.word	-65536
$L43:
	.word	536870912
$L44:
	.word	2097152
$L45:
	.word	-16777216
$L46:
	.word	-16777217
$L47:
	.word	67108864
$L48:
	.word	-67108864
$L49:
	.word	-67108865
	.type	__pend_eq_remote_event_42, @object
__pend_eq_remote_event_42:
	.end	eq_remote_event
	.size	eq_remote_event, .-eq_remote_event
	.ident	"GCC: (Debian 14.2.0-13) 14.2.0"
	.section	.note.GNU-stack,"",@progbits

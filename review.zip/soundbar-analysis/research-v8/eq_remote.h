#ifndef TUVIO_EQ_REMOTE_H
#define TUVIO_EQ_REMOTE_H
#include "eq_core.h"
#define EQ_KEY_CODE 0x51U
#define GEAR_KEY_CODE 0x4eU
#define PLUS_KEY_CODE 0x4fU
#define MINUS_KEY_CODE 0x50U
#define KEY_SHORT_DOWN 0x20000000UL
#define KEY_SHORT_UP 0x04000000UL
#define KEY_LONG_UP 0x02000000UL
#define KEY_HOLD_UP 0x01000000UL
#define KEY_HOLD 0x08000000UL
#define KEY_LONG 0x00200000UL
#define KEY_LONG_DOWN 0x10000000UL
typedef struct { uint8_t eq_held, released; uint32_t released_at; } eq_remote_state;
/* Return nonzero to prevent the stock key mapper handling this event.
 * Long EQ is consumed even if entry fails, preventing the old audio-reset
 * command from running as a fallback. Unrelated keys always pass through. */
int eq_remote_event(eq_editor *,eq_remote_state *,uint32_t raw,uint32_t now,uint32_t generation);
#endif

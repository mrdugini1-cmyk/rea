"""Host-compiled EQ block builder/editor; selected outputs also run through original MIPS16 PEQ copy instructions."""
from pathlib import Path
import ctypes as C,subprocess,struct,json,importlib.util
r=Path(__file__).resolve().parent;R=r.parent
subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-fPIC','-shared',str(r/'eq_core.c'),'-o',str(r/'eq_core.host.so')],check=True)
l=C.CDLL(str(r/'eq_core.host.so'));U=C.c_uint8*512;G=C.c_int8*5
l.eq_make_block.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_int8),C.POINTER(C.c_uint8)];l.eq_make_block.restype=C.c_int
factory=(R/'decoded/resources/music.efx').read_bytes()[:512];slots=[2,5,7,10,13];count=0
sp=importlib.util.spec_from_file_location('parser',r/'check_peq_parser.py');parser=importlib.util.module_from_spec(sp);sp.loader.exec_module(parser);code=(R/'decoded/zephyr.bin').read_bytes()
for band in range(5):
 for gain in range(-6,7):
  gains=[0]*5;gains[band]=gain;src=U.from_buffer_copy(factory);dst=U(*([0xaa]*512));assert l.eq_make_block(src,G(*gains),dst)==0
  expected=bytearray(factory);struct.pack_into('<H',expected,4,max(0,gain)*10)
  if gain:
   off=48+8*slots[band];struct.pack_into('<h',expected,off+4,gain*10)
   if struct.unpack_from('<H',factory,8+2*slots[band])[0]==0:struct.pack_into('<H',expected,8+2*slots[band],1)
  assert bytes(dst)==expected and bytes(src)==factory
  # Verify the actual firmware parser carries our changed value to its filter list.
  actual=parser.parse(code,bytes(dst))
  if gain:assert any(rec[0]==[63,250,1000,4000,16000][band] and rec[2]==gain*10 for rec in actual)
  count+=1
for gains in [[6]*5,[-6]*5,[6,-6,6,-6,6]]:
 dst=U();assert l.eq_make_block(U.from_buffer_copy(factory),G(*gains),dst)==0;assert struct.unpack_from('<H',bytes(dst),4)[0]==sum(max(0,g)*10 for g in gains);parser.parse(code,bytes(dst))
for field,value in [(4,65535),(48+8*slots[0],64),(48+8*slots[0]+2,0)]:
 bad=bytearray(factory);struct.pack_into('<H',bad,field,value);dst=U(*([0xaa]*512));assert l.eq_make_block(U.from_buffer_copy(bad),G(),dst)==-1 and bytes(dst)==b'\xaa'*512
assert l.eq_make_block(U.from_buffer_copy(factory),G(7,0,0,0,0),U())==-1
CALL=C.CFUNCTYPE(C.c_int,C.c_void_p,C.POINTER(C.c_int8))
class Editor(C.Structure):
 _fields_=[('saved',G),('draft',G),('editing',C.c_uint8),('band',C.c_uint8),('gain_first',C.c_uint8),('last',C.c_uint32),('generation',C.c_uint32),('opaque',C.c_void_p),('apply',CALL),('save',CALL)]
state={'applied':[],'stored':[],'fail_apply':False,'fail_save':False}
@CALL
def apply(_,g):
 if state['fail_apply']:state['fail_apply']=False;return -1
 state['applied'].append(list(g[:5]));return 0
@CALL
def save(_,g):
 if state['fail_save']:return -1
 state['stored'].append(list(g[:5]));return 0
l.eq_editor_init.argtypes=[C.POINTER(Editor),C.c_void_p,CALL,CALL];l.eq_editor_event.argtypes=[C.POINTER(Editor),C.c_int,C.c_uint32,C.c_uint32]
e=Editor();l.eq_editor_init(C.byref(e),None,apply,save)
def event(a,t=100,g=1):return l.eq_editor_event(C.byref(e),a,t,g)
assert event(3)==0 # Ordinary volume remains unconsumed outside the editor.
assert event(0)==1 and e.editing
assert event(3)==1 and event(3)==1 and e.draft[0]==2
assert event(5)==1 and list(e.saved)==[2,0,0,0,0] and state['stored']==[[2,0,0,0,0]]
assert event(0)==1 and event(4)==1
assert event(8)==0 and not e.editing and state['applied'][-1]==[2,0,0,0,0]
assert event(0)==1 and event(1)==1 and e.band==4 and event(2)==1 and e.band==0
for _ in range(30):assert event(3)==1
assert e.draft[0]==6
assert event(7,15100)==1 and not e.editing and state['applied'][-1]==[2,0,0,0,0]
assert event(0)==1;before=len(state['applied']);assert event(3,g=2)==0 and not e.editing and len(state['applied'])==before
state['fail_apply']=True;assert event(0)==-1 and not e.editing
assert event(0)==1;state['fail_save']=True;assert event(3)==1 and event(5)==-1 and not e.editing and list(e.saved)==[2,0,0,0,0];state['fail_save']=False
assert event(0,0xffffff00)==1 and event(7,(0xffffff00+15000)&0xffffffff)==1 and not e.editing
D=C.c_uint8*4
l.eq_display_frame.argtypes=[C.POINTER(Editor),C.c_uint32,C.POINTER(C.c_uint8),C.POINTER(C.c_uint8)]
assert event(0,100)==1
for band,expected in enumerate([[0,0,6,3],[0,2,5,0],[0,1,20,0],[0,4,20,0],[1,6,20,0]]):
 glyph=D();enabled=D();assert l.eq_display_frame(C.byref(e),100,glyph,enabled)==1 and list(glyph)==expected
 assert event(2,100)==1
assert event(4,100)==1
glyph=D();enabled=D();assert l.eq_display_frame(C.byref(e),100,glyph,enabled)==1 and glyph[0]==14 and glyph[3]==1
assert event(6)==1
assert l.eq_display_frame(C.byref(e),100,glyph,enabled)==0
S=C.c_uint8*16
l.eq_settings_encode.argtypes=[C.POINTER(C.c_int8),C.POINTER(C.c_uint8)]
l.eq_settings_decode.argtypes=[C.POINTER(C.c_uint8),C.POINTER(C.c_int8)]
settings_cases=0
for values in [[-6,-3,0,3,6],[0]*5,[6]*5,[-6]*5]:
 packed=S();decoded=G();assert l.eq_settings_encode(G(*values),packed)==0 and l.eq_settings_decode(packed,decoded)==0 and list(decoded)==values
 for bit in range(128):
  bad=bytearray(packed);bad[bit//8]^=1<<(bit%8);decoded=G(*([99]*5));assert l.eq_settings_decode(S.from_buffer_copy(bad),decoded)==-1 and list(decoded)==[99]*5;settings_cases+=1
result=dict(scope=__doc__,display_labels_checked=True,band_hz=[63,250,1000,4000,16000],gain_range_db=[-6,6],settings_corruption_cases=settings_cases,single_band_cases=count,multi_band_cases=3,original_parser_verified=True,headroom_pre_attenuation=True,unrelated_dsp_bytes_preserved=True,invalid_input_does_not_modify_output=True,editor_cases=['enter','band wrap','gain clamp','save','power passthrough','timeout cancellation','player identity change','apply failure','save failure','timer wrap'],physical_arc_response_verified=False)
(r/'eq-core-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

#include "eq_remote.h"
#include <assert.h>
#include <stdio.h>
static unsigned applied,saved;static int fail;
static int apply(void *p,const int8_t *g){(void)p;(void)g;applied++;return fail?-1:0;}
static int save(void *p,const int8_t *g){(void)p;(void)g;saved++;return 0;}
int main(void){eq_editor e;eq_remote_state r={0};unsigned k,j,n=0;uint32_t types[]={KEY_SHORT_DOWN,KEY_SHORT_UP,KEY_LONG_DOWN,KEY_LONG,KEY_LONG_UP,KEY_HOLD,KEY_HOLD_UP};
 for(k=0;k<256;k++)for(j=0;j<7;j++)if(k!=EQ_KEY_CODE){eq_editor_init(&e,0,apply,save);r=(eq_remote_state){0};assert(eq_remote_event(&e,&r,types[j]|k,1000,1)==0);n++;}
 eq_editor_init(&e,0,apply,save);r=(eq_remote_state){0};assert(eq_remote_event(&e,&r,KEY_SHORT_UP|EQ_KEY_CODE,1000,1)==0);
 assert(eq_remote_event(&e,&r,KEY_LONG|EQ_KEY_CODE,2000,1)==1&&e.editing);
 assert(eq_remote_event(&e,&r,KEY_LONG|EQ_KEY_CODE,2100,1)==1&&applied==1);
 assert(eq_remote_event(&e,&r,KEY_LONG_UP|EQ_KEY_CODE,2200,1)==1);
 assert(eq_remote_event(&e,&r,KEY_SHORT_UP|EQ_KEY_CODE,2250,1)==1&&!saved&&e.editing);
 for(k=0;k<256;k++)if(k!=EQ_KEY_CODE&&k!=GEAR_KEY_CODE&&k!=PLUS_KEY_CODE&&k!=MINUS_KEY_CODE)for(j=0;j<7;j++){assert(eq_remote_event(&e,&r,types[j]|k,2300,1)==0);n++;}
 assert(eq_remote_event(&e,&r,KEY_SHORT_UP|GEAR_KEY_CODE,2400,1)==1&&e.band==1);
 assert(eq_remote_event(&e,&r,KEY_HOLD|PLUS_KEY_CODE,2500,1)==1&&e.draft[1]==1);
 assert(eq_remote_event(&e,&r,KEY_LONG|MINUS_KEY_CODE,2600,1)==1&&e.draft[1]==0);
 assert(eq_remote_event(&e,&r,KEY_SHORT_DOWN|EQ_KEY_CODE,2700,1)==1);
 assert(eq_remote_event(&e,&r,KEY_SHORT_UP|EQ_KEY_CODE,2800,1)==1&&!e.editing&&saved==1);
 fail=1;assert(eq_remote_event(&e,&r,KEY_LONG|EQ_KEY_CODE,4000,1)==-1&&!e.editing);
 printf("remote mapping passed; unrelated key/type passthrough cases=%u; factory long-EQ reset suppressed\n",n);return 0;}

"""Bounded actual MIPS16 getter, button/display and startup-restore checks; no peripherals emulated."""
from pathlib import Path
import struct,json,importlib.util
D=Path(__file__).resolve().parent;R=D.parent;F=R/'candidates/v5.1-eq-channel-limits';code=(F/'zephyr-decoded.bin').read_bytes()
ns={'__file__':str(R/'research-v4/check_v4.py')};exec((R/'research-v4/check_v4.py').read_text().split("folder=R/")[0],ns);old=ns['old'];ButtonVM=ns['VM']
class GetterVM(old.VM):
 def step(self):
  p=self.pc;w=self.word(p)
  if w==0x3384:self.r[3]=(self.r[4]<<1)&0xffffffff
  elif w==0x0a03:self.r[2]=(p&~3)+4*(w&255)
  elif w==0xe26d:self.r[3]=(self.r[2]+self.r[3])&0xffffffff
  elif w==0x8b60:self.r[3]=old.signed(self.load(self.r[3],2),16)&0xffffffff
  elif w==0xe269:self.r[2]=(self.r[2]+self.r[3])&0xffffffff
  elif w==0xea80:self.pc=self.r[2]&~1;return
  elif w==0xe38d:self.r[3]=(self.r[3]+self.r[4])&0xffffffff
  elif w&0xf800==0xf000:
   q=self.word(p+2);imm=((w&31)<<11)|(w&0x7e0)|(q&31)
   assert q&0xf800==0xa000
   self.r[old.C[(q>>5)&7]]=self.load(self.r[old.C[(q>>8)&7]]+imm,1);self.pc=p+4;return
  else:return super().step()
  self.pc=p+2
count=0
for key in range(14):
 for value in range(256):
  v=GetterVM(code);v.r[4]=key;v.put(0xbfc25fc4,0x1e0000)
  for off in range(64,76):v.put(0x1e0000+off,value,1)
  before=v.r.copy();v.run(0xbf03d084);expected=max(6,min(16,value)) if key in [2,4] else (0 if key in [8,13] else value)
  assert v.r[2]==expected,(key,value,v.r[2],expected)
  for reg in range(32):
   if reg not in [2,3,24]:assert v.r[reg]==before[reg],(key,value,reg)
  for off in range(64,76):assert v.load(0x1e0000+off,1)==(expected if key in [2,4] and off==64+key else value)
  count+=1
result={'scope':__doc__,'getter_input_cases':count,'channels':{},'hardware_tested':False}
for name,fn,ui,idx,reg in [('SW',0x4e01c,0x48438,2,6),('SURR',0x4e110,0x484ac,4,5)]:
 for value in range(6,17):
  for direction in [0,1]:
   v=ButtonVM(code);v.getter=value;v.r[4]=direction;v.run(old.BASE+fn);expected=min(16,value+1) if direction==0 else max(6,value-1)
   assert v.setter==(idx,expected),(name,value,direction,v.setter)
   assert v.packet==bytes([0x81,reg,expected-6]),(name,value,direction,v.packet)
  v=ButtonVM(code);v.r[2]=value;v.run(old.BASE+ui,stops=(0xbf0483ba,0xbf0483d8,0xbf048422))
  assert v.pc==(0xbf0483ba if value<11 else 0xbf0483d8 if value==11 else 0xbf048422)
  if value!=11:assert v.r[17]==abs(value-11)
 result['channels'][name]={'button_packet_cases':22,'display_values':11,'wire_bytes':[0,10],'display_range':[-5,5]}
for value in range(256):
 v=ButtonVM(code);v.getter=max(6,min(16,value));v.run(0xbf04e298);assert v.packet==bytes([0x81,6,max(6,min(16,value))-6])
result['SW_restore_composed_cases']=256
(F/'channel-limits-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

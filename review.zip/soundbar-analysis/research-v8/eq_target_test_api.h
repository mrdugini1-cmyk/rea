#include <stddef.h>
extern uint8_t *eq_test_root;
extern uint8_t eq_test_original[76],eq_test_mode,eq_test_display_state;
extern uint8_t eq_test_ui_dirty,eq_test_ui_age;
#define UI_DIRTY eq_test_ui_dirty
#define UI_AGE eq_test_ui_age
extern uint16_t eq_test_display_count;
#define ROOT_POINTER eq_test_root
#define STATIC_CONFIG eq_test_original
#define CURRENT_MODE eq_test_mode
#define DISPLAY_COUNT eq_test_display_count
#define DISPLAY_STATE eq_test_display_state
void *target_alloc(unsigned);
void *target_memset(void *,int,unsigned);
void *target_player(void);
const char *target_app(void);
int target_param(void *,int,const void *,unsigned);
const uint8_t *target_effect(unsigned,unsigned,int *);
int target_get(const char *,void *,unsigned);
int target_set(const char *,const void *,unsigned);
int target_flush(const char *);
void target_draw(unsigned,unsigned,unsigned);
uint32_t target_uptime(void);
int target_dispatch(uint32_t);
void target_timer(void *);

#include "eq_core.h"
const uint16_t eq_frequencies[EQ_BANDS] = {63,250,1000,4000,16000};
static const uint8_t slots[EQ_BANDS] = {2,5,7,10,13};
static uint16_t read16(const uint8_t *b) { return (uint16_t)b[0] | ((uint16_t)b[1]<<8); }
static void write16(uint8_t *b, uint16_t x) { b[0]=(uint8_t)x; b[1]=(uint8_t)(x>>8); }
static void copy_gain(int8_t *d,const int8_t *s) { unsigned i; for(i=0;i<EQ_BANDS;i++)d[i]=s[i]; }
int eq_make_block(const uint8_t factory[EQ_BLOCK_SIZE],const int8_t gain[EQ_BANDS],uint8_t output[EQ_BLOCK_SIZE]) {
 unsigned i; uint16_t precut;
 if(!factory||!gain||!output||factory==output||read16(factory)!=1)return -1;
 precut=read16(factory+4);
 if(precut>600)return -1;
 for(i=0;i<EQ_BANDS;i++) {
  const uint8_t *record=factory+48+8*slots[i]; uint16_t route=read16(factory+8+2*slots[i]);
  int combined=(int16_t)read16(record+4)+10*(int)gain[i];
  if(gain[i]<EQ_GAIN_MIN||gain[i]>EQ_GAIN_MAX||read16(record)!=eq_frequencies[i]||
     read16(record+2)!=7||read16(record+6)!=1||route>2||combined < -240||combined>120)return -1;
  if(gain[i]>0)precut=(uint16_t)(precut+10*gain[i]);
 }
 /* Sum of positive boosts reserves conservative headroom; unrelated DRC,
    limiter and unselected factory filters remain byte-for-byte unchanged. */
 if(precut>600)return -1;
 for(i=0;i<EQ_BLOCK_SIZE;i++)output[i]=factory[i];
 write16(output+4,precut);
 for(i=0;i<EQ_BANDS;i++) {
  unsigned record=48+8*slots[i];
  if(gain[i]) {
   write16(output+record+4,(uint16_t)((int16_t)read16(factory+record+4)+10*gain[i]));
   if(!read16(factory+8+2*slots[i]))write16(output+8+2*slots[i],1);
  }
 }
 return 0;
}
void eq_editor_init(eq_editor *e,void *opaque,eq_apply_fn apply,eq_save_fn save) {
 unsigned i; for(i=0;i<EQ_BANDS;i++)e->saved[i]=e->draft[i]=0;
 e->editing=0;e->band=0;e->gain_first=0;e->last_action_ms=0;e->player_generation=0;e->opaque=opaque;e->apply=apply;e->save=save;
}
static int cancel(eq_editor *e,int restore) {
 int rc=0;
 if(restore&&e->apply)rc=e->apply(e->opaque,e->saved);
 copy_gain(e->draft,e->saved);e->editing=0;return rc? -1:1;
}
int eq_editor_event(eq_editor *e,enum eq_action action,uint32_t now,uint32_t generation) {
 int8_t next[EQ_BANDS];
 if(e->editing&&generation!=e->player_generation){cancel(e,0);return 0;}
 if(action==EQ_POWER_OR_SOURCE){if(e->editing)cancel(e,1);return 0;}
 if(action==EQ_OPEN){
  if(!e->editing){if(!e->apply||e->apply(e->opaque,e->saved))return -1;copy_gain(e->draft,e->saved);e->band=0;e->gain_first=0;e->editing=1;e->player_generation=generation;}
  e->last_action_ms=now;return 1;
 }
 if(!e->editing)return 0;
 if(action==EQ_TICK){if((uint32_t)(now-e->last_action_ms)>=15000U)return cancel(e,1);return 0;}
 e->last_action_ms=now;
 if(action==EQ_CANCEL)return cancel(e,1);
 if(action==EQ_SAVE_EXIT){
  if(!e->save||e->save(e->opaque,e->draft)){cancel(e,1);return -1;}
  copy_gain(e->saved,e->draft);e->editing=0;return 1;
 }
 if(action==EQ_NEXT_BAND){e->gain_first=0;e->band=(uint8_t)((e->band+1U)%EQ_BANDS);return 1;}
 if(action==EQ_PREVIOUS_BAND){e->gain_first=0;e->band=(uint8_t)((e->band+EQ_BANDS-1U)%EQ_BANDS);return 1;}
 if(action!=EQ_GAIN_UP&&action!=EQ_GAIN_DOWN)return 0;
 e->gain_first=1;
 copy_gain(next,e->draft);
 if(action==EQ_GAIN_UP){if(next[e->band]>=EQ_GAIN_MAX)return 1;next[e->band]++;}
 else {if(next[e->band]<=EQ_GAIN_MIN)return 1;next[e->band]--;}
 if(e->apply(e->opaque,next)){cancel(e,1);return -1;}
 copy_gain(e->draft,next);return 1;
}

static uint16_t settings_crc(const uint8_t *bytes) {
 uint16_t crc=0xffff; unsigned i,j;
 for(i=0;i<14;i++){crc^=(uint16_t)bytes[i]<<8;for(j=0;j<8;j++)crc=(uint16_t)((crc<<1)^((crc&0x8000)?0x1021:0));}
 return crc;
}
int eq_settings_encode(const int8_t gain[EQ_BANDS],uint8_t output[EQ_SETTINGS_SIZE]) {
 unsigned i;
 if(!gain||!output)return -1;
 for(i=0;i<EQ_BANDS;i++)if(gain[i]<EQ_GAIN_MIN||gain[i]>EQ_GAIN_MAX)return -1;
 for(i=0;i<EQ_SETTINGS_SIZE;i++)output[i]=0;
 output[0]='T';output[1]='E';output[2]='Q';output[3]='1';output[4]=1;output[5]=EQ_BANDS;output[6]=EQ_GAIN_MAX;
 for(i=0;i<EQ_BANDS;i++)output[8+i]=(uint8_t)gain[i];
 write16(output+14,settings_crc(output));return 0;
}
int eq_settings_decode(const uint8_t input[EQ_SETTINGS_SIZE],int8_t gain[EQ_BANDS]) {
 unsigned i;
 if(!input||!gain||input[0]!='T'||input[1]!='E'||input[2]!='Q'||input[3]!='1'||input[4]!=1||input[5]!=EQ_BANDS||input[6]!=EQ_GAIN_MAX||input[7]||input[13]||read16(input+14)!=settings_crc(input))return -1;
 for(i=0;i<EQ_BANDS;i++)if((int8_t)input[8+i]<EQ_GAIN_MIN||(int8_t)input[8+i]>EQ_GAIN_MAX)return -1;
 for(i=0;i<EQ_BANDS;i++)gain[i]=(int8_t)input[8+i];
 return 0;
}

/* Original display glyphs: digits 0..9, A..Z 10..35, minus 40,
 * plus 41. Positions 0..3 can each be disabled to produce a blank. */
int eq_display_frame(const eq_editor *e,uint32_t now,uint8_t glyph[4],uint8_t enabled[4]) {
 static const uint8_t labels[EQ_BANDS][4]={{0,0,6,3},{0,2,5,0},{0,1,20,0},{0,4,20,0},{1,6,20,0}};
 static const uint8_t masks[EQ_BANDS][4]={{0,1,1,1},{1,1,1,1},{0,1,1,0},{0,1,1,0},{1,1,1,0}};
 unsigned i;uint32_t phase;int gain,show_gain;
 if(!e||!glyph||!enabled||!e->editing)return 0;
 if(e->band>=EQ_BANDS||e->draft[e->band]<EQ_GAIN_MIN||e->draft[e->band]>EQ_GAIN_MAX)return -1;
 phase=(uint32_t)(now-e->last_action_ms)%1800U;
 show_gain=e->gain_first?phase<1200U:phase>=600U;
 if(!show_gain){for(i=0;i<4;i++){glyph[i]=labels[e->band][i];enabled[i]=masks[e->band][i];}return 1;}
 gain=e->draft[e->band];glyph[0]=14;glyph[1]=(uint8_t)(gain<0?40:41);glyph[2]=0;glyph[3]=(uint8_t)(gain<0?-gain:gain);
 enabled[0]=1;enabled[1]=(uint8_t)(gain!=0);enabled[2]=1;enabled[3]=1;return 1;
}

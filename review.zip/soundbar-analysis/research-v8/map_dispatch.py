from pathlib import Path
import struct,json
R=Path(__file__).resolve().parent.parent;b=(R/'decoded/zephyr.bin').read_bytes();BASE=0xbf000000
C=[16,17,2,3,4,5,6,7]
def signed(v,n):return v-(1<<n) if v&(1<<(n-1)) else v
def leaf(command):
 regs={2:command};flag=0;p=0x18238
 for _ in range(100):
  w=struct.unpack_from('<H',b,p)[0];q=None;size=2;imm=w&255
  if w&0xf800==0xf000:q=struct.unpack_from('<H',b,p+2)[0];imm=((w&31)<<11)|(w&0x7e0)|(q&31);w=q;size=4
  n=p+size
  if w&0xff00==0x7200:flag=regs[2]^(w&255)
  elif w&0xff00==0x5a00:flag=int(regs[2]<imm)
  elif w&0xff00 in [0x6000,0x6100]:
   take=(flag==0) if w&0xff00==0x6000 else (flag!=0)
   if take:n=p+size+2*signed(imm,16 if size==4 else 8)
  elif w in [0x6718,0x6778]:regs[16 if w==0x6718 else 3]=flag
  elif w&0xf800 in [0x2000,0x2800]:
   r=C[(w>>8)&7];take=(regs.get(r,0)==0) if w&0xf800==0x2000 else (regs.get(r,0)!=0)
   if take:n=p+size+2*signed(imm,16 if size==4 else 8)
  elif w&0xf800==0x1000:n=p+2+2*signed(w&2047,11)
  else:return p
  p=n
 raise AssertionError(command)
ls=(R/'disassembly-mips16.txt').read_text().splitlines();lineidx={int(s.split(':')[0].strip(),16):i for i,s in enumerate(ls) if ':' in s and s.strip().startswith('bf')}
result=[]
for c in range(0x20,0x4b):
 p=leaf(c);i=lineidx.get(BASE+p,0);snippet=ls[i:i+12];result.append(dict(command=hex(c),leaf=hex(BASE+p),snippet='\n'.join(snippet)))
 print(hex(c),hex(BASE+p),' '.join(x.split('\t')[-1].strip() for x in snippet[:3]))
(R/'research-v7/command-leaves.json').write_text(json.dumps(result,indent=2))

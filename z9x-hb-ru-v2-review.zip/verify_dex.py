from pathlib import Path
import subprocess,concurrent.futures,json,hashlib,struct,zlib,re,sys
r=Path(__file__).resolve().parent;src=r/'smali-patched';dst=r/'smali-roundtrip';results={}
def work(name):
 p=r/'patched-dex'/name;b=p.read_bytes();assert b[:4]==b'dex\n';assert struct.unpack_from('<I',b,8)[0]==zlib.adler32(b[12:]);assert b[12:32]==hashlib.sha1(b[32:]).digest();assert struct.unpack_from('<I',b,32)[0]==len(b)
 if name=='classes.dex':return name,{'unchanged':True,'checksum_valid':True}
 if '--reuse' not in sys.argv:
  t=subprocess.run(['java','-Xmx1g','-cp',str(r.parent/'tools/smali/*'),'org.jf.baksmali.Main','d','--api','33','-j','2',str(p),'-o',str(dst/name[:-4])],capture_output=True,text=True);assert t.returncode==0,t.stderr
  assert t.returncode==0,t.stderr
 a=src/name[:-4];d=dst/name[:-4];files={f.relative_to(a) for f in a.rglob('*.smali')};assert files=={f.relative_to(d) for f in d.rglob('*.smali')};mismatches=[];default_normalizations=[]
 def normalize(text):
  # DEX omits trailing explicit zero/null static initializers; their language defaults are identical.
  return re.sub(r'(?m)^(\.field[^\n]*\bstatic\b[^\n]*) = (?:false|null|0x0L?|0\.0f)$',r'\1',text)
 for f in files:
  if (a/f).read_bytes()!=(d/f).read_bytes():
   if normalize((a/f).read_text())==normalize((d/f).read_text()):default_normalizations.append(str(f))
   else:mismatches.append(str(f))
 print(name,'classes',len(files),'mismatches',len(mismatches),mismatches[:6],flush=True)
 return name,dict(classes=len(files),normalized_smali_roundtrip_identical=not mismatches,explicit_default_initializer_normalizations=default_normalizations,mismatches=mismatches,checksum_valid=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for k,v in ex.map(work,['classes.dex','classes2.dex','classes3.dex','classes4.dex','classes5.dex']):results[k]=v
(r/'dex-verification.json').write_text(json.dumps(results,indent=2))
assert all(x.get('unchanged') or x['normalized_smali_roundtrip_identical'] for x in results.values())

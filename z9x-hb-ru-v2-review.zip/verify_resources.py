from pathlib import Path
import zipfile,sys,json,xml.etree.ElementTree as E,re
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r.parent/'translation-v1'));import resource_patch as p
src=r.parent/'translation-v1/translated-resources.zip';a=zipfile.ZipFile(src);b=zipfile.ZipFile(r/'translated-resources-v2.zip');x=a.read('resources.arsc');y=b.read('resources.arsc')
def strings(data):
 off,_,_,n=next(v for v in p.chunks(data,p.U16(data,2),len(data)) if v[1]==1);return p.pool_strings(data[off:off+n])
sx,sy=strings(x),strings(y);assert sy[:len(sx)]==sx;ex,ey=list(p.entries(x)),list(p.entries(y));assert len(ex)==len(ey);changed=[];fmt=lambda x:sorted(re.findall(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z%]',x))
for u,v in zip(ex,ey):
 assert {k:i for k,i in u.items() if k not in ('position','value')}=={k:i for k,i in v.items() if k not in ('position','value')}
 if u['value']!=v['value']:
  assert u['default'] and u['value_type']==3 and u['type'] in ('string','array') and v['value']>=len(sx)
  assert fmt(sx[u['value']])==fmt(sy[v['value']]);changed.append(v)
assert sum(v['type']=='string' for v in changed)==924
assert sum(v['type']=='array' for v in changed)==3
assert a.namelist()==b.namelist()
for name in a.namelist():
 if name!='resources.arsc':assert a.read(name)==b.read(name),name
old=r.parent/'settings-resources/resources';new=r/'decoded-check/resources';assert (old/'AndroidManifest.xml').read_bytes()==(new/'AndroidManifest.xml').read_bytes();assert (old/'res/values/public.xml').read_bytes()==(new/'res/values/public.xml').read_bytes()
for d in (old/'res').glob('values-*'):
 for f in d.glob('*.xml'):assert f.read_bytes()==(new/'res'/d.name/f.name).read_bytes(),str(f)
remaining=[]
for f in (new/'res').rglob('*.xml'):
 if f.parent.name.startswith('values-'):continue
 for e in E.parse(f).getroot().iter():
  for text in [e.text or '',*e.attrib.values()]:
   if re.search('[\u4e00-\u9fff]',text):remaining.append(str(f.relative_to(new)))
assert not remaining,remaining
result=dict(table_entries=len(ex),editorial_strings=924,array_items=3,all_original_resource_ids_preserved=True,all_old_pool_strings_and_indices_preserved=True,existing_localized_resources_preserved=True,format_placeholders_preserved=True,manifest_unchanged=True,independent_jadx_decode_passed=True,default_resource_cjk_remaining=remaining,hardware_tested=False)
(r/'resource-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

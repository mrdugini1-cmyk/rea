"""Resource-only patch. Keeps resource IDs and original string indices stable.
Does not produce an installable/signed system APK.
"""
from pathlib import Path
import struct,json,re,hashlib,zipfile,sys
U16=lambda b,o:struct.unpack_from('<H',b,o)[0]
U32=lambda b,o:struct.unpack_from('<I',b,o)[0]
def chunks(b,start,end):
 while start<end:
  t,h,n=struct.unpack_from('<HHI',b,start);assert h>=8 and n>=h and start+n<=end,(start,t,h,n)
  yield start,t,h,n
  start+=n
 assert start==end

def pool_strings(b):
 assert U16(b,0)==1
 n=U32(b,8);flags=U32(b,16);start=U32(b,20);strings=[]
 def length(p,utf8):
  if utf8:
   v=b[p];return (((v&127)<<8)|b[p+1],p+2) if v&128 else (v,p+1)
  v=U16(b,p);return (((v&32767)<<16)|U16(b,p+2),p+4) if v&32768 else (v,p+2)
 for i in range(n):
  p=start+U32(b,U16(b,2)+i*4)
  if flags&256:
   _,p=length(p,True);ln,p=length(p,True);strings.append(b[p:p+ln].decode('utf8'))
  else:
   ln,p=length(p,False);strings.append(b[p:p+2*ln].decode('utf-16le'))
 return strings

def repool(b,append=(),replace=None):
 old=pool_strings(b);strings=old+list(append);replace=replace or {};strings=[replace.get(i,s) for i,s in enumerate(strings)];h=U16(b,2);styles=U32(b,12);flags=U32(b,16)&~1;oldcount=len(old);offs=[];data=bytearray()
 def ln(v,utf8):
  if utf8:
   assert v<32768;return bytes([(v>>8)|128,v&255]) if v>127 else bytes([v])
  return struct.pack('<HH',(v>>16)|32768,v&65535) if v>32767 else struct.pack('<H',v)
 for s in strings:
  offs.append(len(data));utf16=s.encode('utf-16le');utf8=s.encode('utf8')
  data+=ln(len(utf16)//2,bool(flags&256))
  if flags&256:data+=ln(len(utf8),True)+utf8+b'\0'
  else:data+=utf16+b'\0\0'
 data+=b'\0'*((-len(data))%4)
 styleoffs=b[h+oldcount*4:h+(oldcount+styles)*4];styledata=b[U32(b,24):] if U32(b,24) else b'';head=bytearray(b[:h]);start=h+4*len(strings)+len(styleoffs);struct.pack_into('<IIIII',head,8,len(strings),styles,flags,start,start+len(data) if styledata else 0);out=head+b''.join(struct.pack('<I',v) for v in offs)+styleoffs+data+styledata;struct.pack_into('<I',out,4,len(out));assert pool_strings(out)==strings;return out

def entries(b):
 for p,t,h,n in chunks(b,U16(b,2),len(b)):
  if t!=0x200:continue
  pkg=U32(b,p+8);kp=p+U32(b,p+276);keys=pool_strings(b[kp:kp+U32(b,kp+4)]);tp=p+U32(b,p+268);types=pool_strings(b[tp:tp+U32(b,tp+4)]);typeoff=U32(b,p+284) if h>=288 else 0
  for q,tt,hh,nn in chunks(b,p+h,p+n):
   if tt!=0x201:continue
   typeid=b[q+8];flags=b[q+9];count=U32(b,q+12);es=q+U32(b,q+16);config=bytes(b[q+20:q+20+U32(b,q+20)]);default=not any(config[4:]);locale=config[8:12]
   if flags&1:offsets=[(U16(b,q+hh+i*4),U16(b,q+hh+i*4+2)*4) for i in range(count)]
   elif flags&2:offsets=[(i,U16(b,q+hh+i*2)*4) for i in range(count) if U16(b,q+hh+i*2)!=65535]
   else:offsets=[(i,U32(b,q+hh+i*4)) for i in range(count) if U32(b,q+hh+i*4)!=0xffffffff]
   for i,off in offsets:
    e=es+off;size=U16(b,e);ef=U16(b,e+2);assert not ef&8,'compact entries unsupported';key=keys[U32(b,e+4)];rid=(pkg<<24)|((typeid+typeoff)<<16)|i
    if ef&1:
     for j in range(U32(b,e+12)):
      v=e+size+12*j+4
      yield dict(id=rid,name=key,type=types[typeid-1],default=default,locale=locale.hex(),value_type=b[v+3],value=U32(b,v+4),position=v+4,bag=j)
    else:
     v=e+size;yield dict(id=rid,name=key,type=types[typeid-1],default=default,locale=locale.hex(),value_type=b[v+3],value=U32(b,v+4),position=v+4,bag=None)

def patch_arsc(b,translations):
 assert U16(b,0)==2 and U32(b,4)==len(b)
 pools=[(p,h,n) for p,t,h,n in chunks(b,U16(b,2),len(b)) if t==1];assert len(pools)==1;p,h,n=pools[0];oldpool=b[p:p+n];ss=pool_strings(oldpool);out=bytearray(b);append=[];changes=[]
 for e in entries(b):
  if e['type']!='string' or e['value_type']!=3 or not e['default']:continue
  name=e['name'];s=ss[e['value']]
  if name=='remoteTv3':
   # This is structured JSON. Change only its display name, never an Intent or package.
   assert '镜头记忆' in s;new=s.replace('镜头记忆','Память объектива')
  elif name in translations:new=translations[name].replace('\\n','\n').replace('\\t','\t')
  else:continue
  assert re.search('[\u4e00-\u9fff]',s),name
  fmt=lambda x:sorted(re.findall(r'%(?:\d+\$)?[-#+ 0,(]*\d*(?:\.\d+)?[a-zA-Z%]',x))
  assert fmt(s)==fmt(new),(name,s,new)
  struct.pack_into('<I',out,e['position'],len(ss)+len(append));append.append(new);changes.append(dict(name=name,resource_id=hex(e['id']),before=s,after=new))
 newpool=repool(oldpool,append);out=out[:p]+newpool+out[p+n:];struct.pack_into('<I',out,4,len(out));return bytes(out),changes

def patch_xml(b,mapping):
 assert U16(b,0)==3 and U32(b,4)==len(b)
 out=bytearray(b);changes=[]
 for p,t,h,n in chunks(b,U16(b,2),len(b)):
  if t!=1:continue
  ss=pool_strings(b[p:p+n]);replace={i:mapping[s] for i,s in enumerate(ss) if s in mapping};changes=[dict(before=ss[i],after=v) for i,v in replace.items()]
  out=out[:p]+repool(b[p:p+n],replace=replace)+out[p+n:];struct.pack_into('<I',out,4,len(out));break
 return bytes(out),changes

if __name__=='__main__':
 r=Path(__file__).resolve().parent;source=Path(sys.argv[1]);z=zipfile.ZipFile(source);translations=dict(l.split('\t',1) for l in (r/'ru-additions.tsv').read_text().splitlines());b=z.read('resources.arsc');print('entries',len(list(entries(b))));patched,changes=patch_arsc(b,translations);assert len(changes)==262,(len(changes),set(translations)-{v['name'] for v in changes});out=r/'patched';out.mkdir(exist_ok=True);(out/'resources.arsc').write_bytes(patched)
 mapping={'旋转画面':'Поворот изображения','输入分享码，获得滤镜':'Введите код, чтобы получить фильтр','位移画面':'Сдвиг изображения','缩放画面':'Масштаб изображения','发货福克斯的借款方加快速度就反馈四大皆空房价多少控件发':'Описание','画面不是矩形':'Изображение не прямоугольное','画面旋转':'Изображение повёрнуто','完成校准':'Завершить калибровку','我知道了':'Понятно','测试效果':'Проверка результата','当前连接WIFI:  XGIMI-5G':'Текущая сеть Wi-Fi: XGIMI-5G','返回':'Назад','服务协议':'Условия использования','加入用户体验计划':'Участвовать в программе улучшения качества'}
 xmlchanges={}
 with zipfile.ZipFile(r/'translated-resources.zip','w',zipfile.ZIP_DEFLATED) as w:
  for item in z.infolist():
   data=z.read(item)
   if item.filename=='resources.arsc':data=patched
   elif item.filename.startswith('res/') and item.filename.endswith('.xml') and data[:2]==b'\x03\x00':
    data,c=patch_xml(data,mapping)
    if c:xmlchanges[item.filename]=c
   w.writestr(item,data)
 (r/'changes.json').write_text(json.dumps(dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),arsc_source_sha256=hashlib.sha256(b).hexdigest(),arsc_patched_sha256=hashlib.sha256(patched).hexdigest(),strings=changes,layouts=xmlchanges,hardware_tested=False,installable_apk=False),ensure_ascii=False,indent=2));print('translated',len(changes),'layout_files',len(xmlchanges),'layout_values',sum(map(len,xmlchanges.values())))

"""Checks repackaging against a fixture assembled from supplied APK parts.
The fixture has sentinel assets/native data; it is not an installable APK.
"""
from pathlib import Path
import tempfile,zipfile,json,hashlib
from apply_to_original import build
r=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='projector-merge-',dir='/tmp') as tmp:
 d=Path(tmp);source=d/'fixture.apk';out=d/'candidate.UNSIGNED.apk'
 with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as w:
  with zipfile.ZipFile('/workspace/attachments/4aeb67a1-511f-468c-ad86-7167e2fbd9b8/projector-settings.zip') as z:
   for i in z.infolist():w.writestr(i,z.read(i))
  for name,path in json.loads((r/'dex-sources.json').read_text()).items():w.write(path,name)
  for name,data in [('assets/unchanged.bin',b'fixture asset\0\xff'),('lib/arm64-v8a/libfixture.so',b'not an ELF; fixture only'),('META-INF/NOTICE',b'fixture licence'),('META-INF/SIGNER.RSA',b'stale fixture signature'),('META-INF/SIGNER.SF',b'stale fixture signature'),('META-INF/MANIFEST.MF',b'stale fixture signature')]:w.writestr(name,data)
 before=hashlib.sha256(source.read_bytes()).hexdigest();report=build(source,r/'z9x-hb-ru-v2-payload.zip',out);assert before==hashlib.sha256(source.read_bytes()).hexdigest()
 with zipfile.ZipFile(source) as src,zipfile.ZipFile(out) as dst:
  for n in ['assets/unchanged.bin','lib/arm64-v8a/libfixture.so','META-INF/NOTICE','classes.dex','AndroidManifest.xml']:assert src.read(n)==dst.read(n)
  for n in ['META-INF/SIGNER.RSA','META-INF/SIGNER.SF','META-INF/MANIFEST.MF']:assert n not in dst.namelist()
 try:build(source,r/'z9x-hb-ru-v2-payload.zip',out)
 except ValueError:pass
 else:raise AssertionError('existing output was not refused')
 bad=d/'wrong.apk'
 with zipfile.ZipFile(source) as z,zipfile.ZipFile(bad,'w') as w:
  for i in z.infolist():w.writestr(i,b'wrong version' if i.filename=='resources.arsc' else z.read(i))
 rejected=d/'should-not-exist.apk'
 try:build(bad,r/'z9x-hb-ru-v2-payload.zip',rejected)
 except ValueError:assert not rejected.exists()
 else:raise AssertionError('wrong input accepted')
 result=dict(source_is_synthetic_fixture=True,full_real_apk_available=False,source_unchanged=True,all_replacements_verified=True,unrelated_assets_native_data_and_notices_preserved=True,stale_v1_signatures_removed=True,wrong_version_rejected=True,existing_output_refused=True,install_tested=False)
 (r/'merge-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
